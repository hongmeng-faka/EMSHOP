<?php


class Goods_Controller {

    function display($params) {
        $options_cache = Option::getAll();
        extract($options_cache);
        Api::local_init();
        $sort = Api::getSortAll();
        $sortid = null;
        $goods_list = Api::getGoodsList([
            'keyword' => Input::getStrVar('q'),
            'sort_id' => Input::getStrVar('sort_id'),
            'user_id' => UID,
            'user_level' => LEVEL,
        ]);
        doAction('home_goods_list_control');

//        d($goods_list);die;
        $templateModel = new Template_Model();
        $templateInfo = $templateModel->getCurrentTemplate();
        if($templateInfo['header_and_footer'] == 'common'){
            include View::getCommonView('header');
            include View::getView('goods_list');
            include View::getCommonView('footer');
        }else{
            include View::getHeaderView('header');
            include View::getView('goods_list');
            include View::getFooterView('footer');
        }
    }

    function displayContent($params) {
        global $stationData;

        $goodsModel = new Goods_Model();
        $CACHE = Cache::getInstance();

        $options_cache = $CACHE->readCache('options');
        if($stationData['id'] != 0){
            $options_cache['site_title'] = $stationData['title'];
            $options_cache['blogname'] = $stationData['name'];
        }

        extract($options_cache);

        $goods_id = 0;
        if (isset($params[1])) {
            if ($params[1] == 'post' || $params[1] == 'buy') {
                $goods_id = isset($params[2]) ? (int)$params[2] : 0;
            } elseif (is_numeric($params[1])) {
                $goods_id = (int)$params[1];
            } else {
                $goods_alias_cache = $CACHE->readCache('goods_alias');
                if (!empty($goods_alias_cache)) {
                    $alias = addslashes(urldecode(trim($params[1])));
                    $goods_id = array_search($alias, $goods_alias_cache);
                    if (!$goods_id) {
                        show_404_page();
                    }
                }
            }
        }
        $goods = $goodsModel->getGoodsInfo([
            'goods_id' => $goods_id,
            'user_id' => UID,
            'user_level' => LEVEL,
        ]);
        if($goods == 'noGoods'){
            emMsg('该商品已下架或被删除');
        }
        doMultiAction('goods_content_echo', $goods, $goods);
        $order_required = Option::get('order_required');
        $order_required = json_decode($order_required, true);
        // tdk
        $site_title = $this->setSiteTitle($log_title_style, $goods['title'], $blogname, $site_title, $goods_id);
        $site_description = $this->setSiteDes($site_description, $goods['content'], $goods['id']);

        $meta = [
            'goods_id' => $goods_id,
            'site_title' => $site_title,
            'site_key' => $site_key,
            'site_description' => $site_description,
        ];
        doOnceAction('goods_meta', $meta, $meta);
        extract($meta);

        $templateModel = new Template_Model();
        $templateInfo = $templateModel->getCurrentTemplate();

        $template = !empty($template) && file_exists(TEMPLATE_PATH . $template . '.php') ? $template : 'goods';
        if($templateInfo['header_and_footer'] == 'common'){
            include View::getCommonView('header');
            include View::getView($template);
        }else{
            include View::getHeaderView('header');
            include View::getView($template);
        }
    }

    private function setSiteDes($siteDescription, $logContent, $goods_id) {
        if ($this->isHomePage($goods_id)) {
            return $siteDescription;
        }

        return extractHtmlData($logContent, 90);
    }

    private function setSiteKey($tagIdStr, $siteKey, $goods_id) {
        if ($this->isHomePage($goods_id)) {
            return $siteKey;
        }

        if (empty($tagIdStr)) {
            return $siteKey;
        }

        $tagNames = '';
        $tagModel = new Tag_Model();
        $ids = explode(',', $tagIdStr);

        if ($ids) {
            $tags = $tagModel->getNamesFromIds($ids);
            $tagNames = implode(',', $tags);
        }

        return $tagNames;
    }

    private function setSiteTitle($logTitleStyle, $logTitle, $blogName, $siteTitle, $goods_id) {
        if ($this->isHomePage($goods_id)) {
            return $siteTitle ?: $blogName;
        }

        switch ($logTitleStyle) {
            case '0':
                $articleSeoTitle = $logTitle;
                break;
            case '1':
                $articleSeoTitle = $logTitle . ' - ' . $blogName;
                break;
            case '2':
            default:
                $articleSeoTitle = $logTitle . ' - ' . $siteTitle;
                break;
        }

        return $articleSeoTitle;
    }

    private function isHomePage($goods_id) {
        $homePageId = Option::get('home_page_id');
        if ($homePageId && $homePageId == $goods_id) {
            return true;
        }
        return false;
    }

    

}
