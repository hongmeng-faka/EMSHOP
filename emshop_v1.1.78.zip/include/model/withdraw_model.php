<?php


class Withdraw_Model {

    private $db;
    private $Parsedown;
    private $table;
    private $db_prefix;
    private $timestamp;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->db_prefix = DB_PREFIX;
        $this->table = DB_PREFIX . 'withdraw';
        $this->Parsedown = new Parsedown();
        $this->Parsedown->setBreaksEnabled(true); //automatic line wrapping
        $this->timestamp = time();
    }

    /**
     * 提现通过
     */
    public function pass($id) {
        $update = [
            'status' => 1,
            'finish_time' => $this->timestamp,
        ];
        $this->db->update('withdraw', $update, ['id' => $id]);
    }
    /**
     * 提现拒绝
     */
    public function reject($id) {
        $update = [
            'status' => 2,
            'reject_time' => $this->timestamp,
        ];
        $this->db->update('withdraw', $update, ['id' => $id]);

        $withdraw = $this->db->once_fetch_array("SELECT * FROM " . $this->table . " WHERE id = '" . $id . "'");

        $balanceModel = new Balance_Model();
        $balanceModel->inc($withdraw['user_id'], $withdraw['amount'], '提现拒绝，余额已返回账户');
    }

    /**
     * 获取提现记录列表
     */
    public function getWithdrawList($user_id = null, $page = 1, $pageNum = 10) {
        // 构建WHERE条件
        $where = "";
        if (!empty($user_id)) {
            $where = " WHERE user_id = '" . $user_id . "'";
        }
        
        // 计算偏移量
        $offset = ($page - 1) * $pageNum;
        
        // 查询数据
        $sql = "SELECT * FROM " . $this->table . $where . " ORDER BY id DESC LIMIT " . $offset . "," . $pageNum;
        $result = $this->db->fetch_all($sql);

        // 格式化数据
        foreach($result as &$val){
            $val['create_time'] = date('Y-m-d H:i:s', $val['create_time']);
            $val['status_text'] = '未知状态';
            if($val['status'] == 0){
                $val['status_text'] = '待处理';
            }
            if($val['status'] == 1){
                $val['status_text'] = '提现完成';
            }
            if($val['status'] == 2){
                $val['status_text'] = '申请拒绝，余额已返回账户';
            }
        }
        
        // 查询总记录数
        $countSql = "SELECT COUNT(*) as total FROM " . $this->table . $where;
        $countResult = $this->db->once_fetch_array($countSql);
        
        // 返回结果集和总记录数
        return [
            'list' => $result,
            'total' => $countResult['total']
        ];
    }



}