### <p align="center">快速稳定的轻量级建站系统，打造好用的虚拟商城系统。</p>


### 优势介绍

### 功能简介

- 

### 环境要求

* PHP5.6、PHP7、PHP8，推荐7.4及以上
* MySQL5.6及以上
* 服务器环境推荐：Linux + Nginx



### 授权协议

发布软件所依据的许可证是自由软件基金会的GPLv3(或更高版本)：[LICENSE](/license.txt)
