<?php
/**
 * SKU API - 商品规格统一接口
 * @package EMSHOP
 */

require_once 'globals.php';

$action = Input::requestStrVar('action');
$db = Database::getInstance();

switch ($action) {
    /**
     * 初始化 - 返回 SKU 组件所需的所有数据
     */
    case 'init':
        $goods_id = Input::getIntVar('goods_id', 0);
        $type_id = Input::getIntVar('type_id', 0);
        $goods_type = Input::getStrVar('goods_type', '');

        // 获取所有规格模板
        $templates = $db->fetch_all(
            "SELECT id, name as title FROM " . DB_PREFIX . "goods_type
             WHERE hide='n' AND delete_time IS NULL ORDER BY id DESC"
        );

        // 获取所有会员等级
        $memberModel = new Member_Model();
        $members = $memberModel->getMembersAll();

        // 构建价格字段
        $price_fields = getPriceFields($members);

        // 默认值
        $mode = 'single';
        $spec = [];
        $sku_data = [];
        $remote_skus = []; // 对接商品的 SKU 组合

        // 如果是编辑已有商品
        if ($goods_id > 0) {
            $goods = $db->once_fetch_array(
                "SELECT is_sku, attr_id, type FROM " . DB_PREFIX . "goods WHERE id = {$goods_id}"
            );
            if ($goods) {
                $type_id = (int)$goods['attr_id'];
                $goods_type = $goods['type'];

                // 对接商品 (attr_id = -1)
                if ($type_id == -1) {
                    $mode = 'remote';

                    // 通过 Hook 让插件获取远程规格数据
                    $remote_spec_data = null;
                    doOnceAction('sku_get_remote_spec', [
                        'goods_id' => $goods_id,
                        'goods_type' => $goods_type
                    ], $remote_spec_data);

                    // 如果插件返回了远程规格数据
                    if (!empty($remote_spec_data)) {
                        // 远程返回的 SKU 组合
                        if (!empty($remote_spec_data['sku_combinations'])) {
                            $remote_skus = $remote_spec_data['sku_combinations'];
                        }
                        // 远程返回的价格数据（作为默认值，本地数据优先）
                        if (!empty($remote_spec_data['sku_data'])) {
                            foreach ($remote_spec_data['sku_data'] as $sku_key => $remote_prices) {
                                if (!isset($sku_data[$sku_key])) {
                                    $sku_data[$sku_key] = $remote_prices;
                                }
                            }
                        }
                    }
                } else {
                    $mode = $goods['is_sku'] === 'y' ? 'multi' : 'single';
                }
            }

            // 获取本地已有的 SKU 数据
            $local_sku_data = getSkuDataForGoods($goods_id, $members);
            // 本地数据优先，合并到 sku_data
            $sku_data = array_merge($sku_data, $local_sku_data);
        }

        // 如果有规格模板，获取规格数据（对接商品不需要）
        if ($type_id > 0) {
            $spec = getSpecDataForTemplate($type_id, $goods_id);
        }

        Output::ok([
            'mode' => $mode,
            'type_id' => $type_id,
            'templates' => $templates,
            'members' => $members,
            'price_fields' => $price_fields,
            'spec' => $spec,
            'sku_data' => $sku_data,
            'remote_skus' => $remote_skus // 对接商品的 SKU 组合
        ]);
        break;

    /**
     * 加载规格数据 - 切换模板时调用
     */
    case 'load_spec':
        $type_id = Input::getIntVar('type_id', 0);
        $goods_id = Input::getIntVar('goods_id', 0);

        if ($type_id <= 0) {
            Output::ok(['spec' => []]);
            break;
        }

        $spec = getSpecDataForTemplate($type_id, $goods_id);
        Output::ok(['spec' => $spec]);
        break;

    /**
     * 渲染单规格表格 HTML
     */
    case 'render_single':
        $price_fields = json_decode(stripslashes(Input::getStrVar('price_fields', '[]')), true);
        $sku_data = json_decode(stripslashes(Input::getStrVar('sku_data', '{}')), true);

        ob_start();
        include dirname(__FILE__) . '/views/components/sku/_single.php';
        $html = ob_get_clean();

        echo $html;
        exit;

    /**
     * 渲染多规格表格 HTML
     */
    case 'render_multi':
        $combinations = json_decode(stripslashes(Input::getStrVar('combinations', '[]')), true);
        $price_fields = json_decode(stripslashes(Input::getStrVar('price_fields', '[]')), true);
        $sku_data = json_decode(stripslashes(Input::getStrVar('sku_data', '{}')), true);
        $spec_names = json_decode(stripslashes(Input::getStrVar('spec_names', '[]')), true);

        // 如果 sku_data 是索引数组（键是0,1,2...），根据 combinations 顺序重新映射为关联数组
        if (!empty($sku_data) && !empty($combinations) && isset($sku_data[0])) {
            $remapped_sku_data = [];
            foreach ($combinations as $index => $combo) {
                if (isset($sku_data[$index])) {
                    $remapped_sku_data[$combo['sku']] = $sku_data[$index];
                }
            }
            $sku_data = $remapped_sku_data;
        }

        $sku_combinations = $combinations;

        ob_start();
        include dirname(__FILE__) . '/views/components/sku/_multi.php';
        $html = ob_get_clean();

        echo $html;
        exit;

    /**
     * 渲染规格选择表格 HTML
     */
    case 'render_spec':
        $specs = json_decode(stripslashes(Input::getStrVar('specs', '[]')), true);

        ob_start();
        include dirname(__FILE__) . '/views/components/sku/_spec_table.php';
        $html = ob_get_clean();

        echo $html;
        exit;

    /**
     * 创建规格属性
     */
    case 'create_spec':
        $title = Input::requestStrVar('title');
        $goods_type_id = Input::getStrVar('goods_type_id');

        if (empty($title)) {
            Output::error('请输入规格名称');
        }

        // 检查是否已存在
        $exists = $db->once_fetch_array(
            "SELECT COUNT(*) AS total FROM " . DB_PREFIX . "sku_attr
             WHERE type_id='{$goods_type_id}' AND title='{$title}' AND delete_time IS NULL"
        );
        if ($exists['total'] > 0) {
            Output::error('该规格已存在');
        }

        $db->query(
            "INSERT INTO " . DB_PREFIX . "sku_attr (type_id, title)
             VALUES ('{$goods_type_id}', '{$title}')"
        );
        $spec_id = $db->insert_id();

        Output::ok(['id' => $spec_id]);
        break;

    /**
     * 创建规格值
     */
    case 'create_value':
        $name = Input::requestStrVar('title');
        $spec_id = Input::requestIntVar('spec_id');

        if (empty($name)) {
            Output::error('请输入规格值名称');
        }

        // 检查是否已存在
        $exists = $db->once_fetch_array(
            "SELECT COUNT(*) AS total FROM " . DB_PREFIX . "sku_value
             WHERE attr_id='{$spec_id}' AND name='{$name}' AND delete_time IS NULL"
        );
        if ($exists['total'] > 0) {
            Output::error('该规格值已存在');
        }

        $db->query(
            "INSERT INTO " . DB_PREFIX . "sku_value (attr_id, name)
             VALUES ('{$spec_id}', '{$name}')"
        );
        $value_id = $db->insert_id();

        Output::ok(['id' => $value_id]);
        break;

    default:
        Output::error('无效的操作');
}

/**
 * 根据会员等级构建价格字段数组
 */
function getPriceFields($members) {
    $fields = [
        ['name' => 'guest_price', 'label' => '游客访问(元)', 'required' => true],
        ['name' => 'user_price', 'label' => '登录用户(元)', 'required' => false],
    ];

    // 添加会员等级字段
    foreach ($members as $m) {
        $fields[] = [
            'name' => 'member_' . $m['id'],
            'label' => $m['name'] . '(元)',
            'required' => false,
            'member_id' => $m['id']
        ];
    }

    $fields[] = ['name' => 'market_price', 'label' => '市场价(元)', 'required' => false];
    $fields[] = ['name' => 'cost_price', 'label' => '成本价(元)', 'required' => false];
    $fields[] = ['name' => 'sales', 'label' => '销量', 'required' => false, 'type' => 'number'];

    return $fields;
}

/**
 * 获取已有商品的 SKU 数据
 */
function getSkuDataForGoods($goods_id, $members) {
    $db = Database::getInstance();
    $sku_data = [];

    // 获取 SKU 记录
    $skus = $db->fetch_all(
        "SELECT * FROM " . DB_PREFIX . "skus WHERE goods_id = {$goods_id}"
    );

    // 获取会员价格
    $member_prices = $db->fetch_all(
        "SELECT * FROM " . DB_PREFIX . "member_price WHERE goods_id = {$goods_id}"
    );

    foreach ($skus as $sku) {
        $sku_key = $sku['sku'];
        $sku_data[$sku_key] = [
            'guest_price' => $sku['guest_price'] / 100,
            'user_price' => $sku['user_price'] / 100,
            'market_price' => $sku['market_price'] / 100,
            'cost_price' => $sku['cost_price'] / 100,
            'sales' => $sku['sales'],
            'stock' => $sku['stock']
        ];

        // 添加会员价格
        foreach ($member_prices as $mp) {
            if ($mp['sku'] == $sku_key) {
                $sku_data[$sku_key]['member_' . $mp['member_level']] = $mp['price'] / 100;
            }
        }
    }

    return $sku_data;
}

/**
 * 获取规格模板的规格数据
 */
function getSpecDataForTemplate($type_id, $goods_id = 0) {
    $db = Database::getInstance();

    // 获取规格属性
    $attrs = $db->fetch_all(
        "SELECT id, title FROM " . DB_PREFIX . "sku_attr
         WHERE type_id = {$type_id} AND delete_time IS NULL ORDER BY id ASC"
    );

    if (empty($attrs)) {
        return [];
    }

    $attr_ids = array_column($attrs, 'id');

    // 获取规格值
    $values = $db->fetch_all(
        "SELECT id, attr_id, name as title FROM " . DB_PREFIX . "sku_value
         WHERE attr_id IN (" . implode(',', $attr_ids) . ") AND delete_time IS NULL ORDER BY id ASC"
    );

    // 获取该商品已选中的规格值
    $selected_values = [];
    if ($goods_id > 0) {
        $skus = $db->fetch_all(
            "SELECT sku FROM " . DB_PREFIX . "skus WHERE goods_id = {$goods_id}"
        );
        foreach ($skus as $sku) {
            $ids = explode('-', $sku['sku']);
            $selected_values = array_merge($selected_values, $ids);
        }
        $selected_values = array_unique($selected_values);
    }

    // 构建规格结构
    $spec = [];
    foreach ($attrs as $attr) {
        $attr_values = [];
        $selected = [];

        foreach ($values as $v) {
            if ($v['attr_id'] == $attr['id']) {
                $attr_values[] = [
                    'id' => $v['id'],
                    'title' => $v['title']
                ];
                if (in_array($v['id'], $selected_values)) {
                    $selected[] = $v['id'];
                }
            }
        }

        $spec[] = [
            'id' => $attr['id'],
            'title' => $attr['title'],
            'options' => $attr_values,
            'value' => $selected
        ];
    }

    return $spec;
}
