<?php defined('EM_ROOT') || exit('access denied!'); ?>



</div>

</div>


<a class="scroll-to-top rounded" href="#page-top">
    <i class="icofont-rounded-up"></i>
</a>



</div>
</div>
<?php doAction('adm_footer') ?>

<style>
    /* ==========================================================================
       EM Modal Pro - 自定义弹窗样式系统
       ========================================================================== */
    
    /* 覆盖 Layui 默认弹窗容器 */
    .em-modal-skin {
        border-radius: 20px !important;
        background: transparent !important;
        box-shadow: none !important;
    }
    
    .em-modal-skin .layui-layer-content {
        overflow: visible !important;
        background: transparent !important;
        border-radius: 20px;
    }
    
    /* 核心容器 */
    .em-modal-box {
        background: #ffffff;
        border-radius: 20px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        overflow: hidden;
        position: relative;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }
    
    /* 顶部装饰条 (可选) */
    .em-modal-box::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 6px;
        background: linear-gradient(90deg, #4C7D71, #6BA596);
    }
    
    /* 自定义关闭按钮 */
    .em-modal-close-btn {
        position: absolute;
        top: 16px;
        right: 16px;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background: #F3F4F6;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        z-index: 10;
        color: #9CA3AF;
    }
    .em-modal-close-btn:hover {
        background: #E5E7EB;
        color: #4B5563;
        transform: rotate(90deg);
    }
    .em-modal-close-btn svg {
        width: 18px;
        height: 18px;
        fill: currentColor;
    }

    /* 头部区域 */
    .em-modal-header {
        padding: 40px 32px 24px;
        text-align: center;
        background: #fff;
    }
    
    .em-modal-icon-wrapper {
        width: 64px;
        height: 64px;
        background: #EDF2F1;
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        color: #4C7D71;
    }
    .em-modal-icon-wrapper i {
        font-size: 32px;
    }
    
    .em-modal-title {
        font-size: 24px;
        font-weight: 800;
        color: #111827;
        margin-bottom: 8px;
        letter-spacing: -0.5px;
    }
    
    .em-modal-desc {
        font-size: 14px;
        color: #6B7280;
        line-height: 1.5;
        max-width: 80%;
        margin: 0 auto;
    }

    /* 内容区域 */
    .em-modal-body {
        padding: 0 32px 40px;
        background: #fff;
    }
    
    .em-modal-list {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }
    
    .em-modal-item {
        display: flex;
        align-items: center;
        padding: 16px 20px;
        background: #F9FAFB;
        border: 1px solid #F3F4F6;
        border-radius: 12px;
        transition: all 0.2s;
        text-decoration: none;
        position: relative;
    }
    
    .em-modal-item:hover {
        background: #fff;
        border-color: #4C7D71;
        box-shadow: 0 8px 20px rgba(76, 125, 113, 0.1);
        transform: translateY(-2px);
    }
    
    .em-item-icon {
        width: 40px;
        height: 40px;
        background: #fff;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #4C7D71;
        margin-right: 16px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        flex-shrink: 0;
    }
    
    .em-item-content {
        flex: 1;
        min-width: 0;
    }
    
    .em-item-title {
        font-size: 15px;
        font-weight: 600;
        color: #374151;
        margin-bottom: 2px;
        display: block;
    }
    
    .em-item-sub {
        font-size: 12px;
        color: #9CA3AF;
        display: block;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-family: monospace;
    }
    
    .em-item-action {
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #D1D5DB;
        transition: all 0.2s;
    }
    
    .em-modal-item:hover .em-item-action {
        color: #4C7D71;
        transform: translateX(4px);
    }

    /* 移动端适配 */
    @media (max-width: 640px) {
        .em-modal-header { padding: 32px 24px 20px; }
        .em-modal-body { padding: 0 24px 32px; }
        .em-modal-title { font-size: 20px; }
        .em-modal-item { padding: 14px; }
    }
</style>

<script>

    $('.get-em-buy-info').click(function(){
        loadIndex = layer.load(2);
        $.ajax({
            url: "./index.php?action=get_em_buy_info",
            type: "GET",
            dataType: "json",
            success: function(e){
                if(e.code == 200){
                    var d = e.data || {};
                    var qq = d.service_qq || '';
                    var list = Array.isArray(d.buy_url) ? d.buy_url : [];
                    var clean = function(s){ return String(s || '').replace(/[`'"\s]/g,'').trim(); };
                    var linksHtml = '';
                    list.forEach(function(it){
                        var name = it.name || '官方授权渠道';
                        var url = clean(it.url);
                        if(url){
                            linksHtml += `
                                <a href="${url}" target="_blank" rel="noopener" class="em-modal-item">
                                    <div class="em-item-icon"><i class="layui-icon layui-icon-cart"></i></div>
                                    <div class="em-item-content">
                                        <span class="em-item-title">${name}</span>
                                        <span class="em-item-sub">${url}</span>
                                    </div>
                                    <div class="em-item-action"><i class="layui-icon layui-icon-right"></i></div>
                                </a>
                            `;
                        }
                    });
                    
                    var isMobile = window.innerWidth < 640;
                    var area = isMobile ? ['90%', 'auto'] : ['520px', 'auto'];
                    var desc = qq ? ('官方客服QQ：' + qq) : '请通过官方认证渠道获取正版授权';
                    
                    var content = `
                        <div class="em-modal-box">
                            <div class="em-modal-close-btn" onclick="layer.close(layer.index)">
                                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
                            </div>
                            <div class="em-modal-header">
                                <div class="em-modal-icon-wrapper"><i class="layui-icon layui-icon-diamond"></i></div>
                                <div class="em-modal-title">获取正版授权码</div>
                                <div class="em-modal-desc">${desc}</div>
                            </div>
                            <div class="em-modal-body">
                                <div class="em-modal-list">
                                    ${linksHtml}
                                </div>
                            </div>
                        </div>
                    `;
                    
                    layer.open({
                        type: 1,
                        title: false,
                        closeBtn: 0,
                        area: area,
                        shadeClose: true,
                        skin: 'em-modal-skin',
                        btn: false,
                        content: content
                    });
                }else{
                    layer.msg(e.msg, {icon: 2});
                }
            },
            error: function(xhr, textStatus, errorThrown){
                layer.msg('网络请求超时，请重试或更换其他线路~', {icon: 2});
            },
            complete: function(){
                layer.close(loadIndex);
            }
        });
    })


    $(function () {
        $(document).on('click', 'a.scroll-to-top', function (e) {
            var $anchor = $(this);
            $('html, body').stop().animate({
                scrollTop: ($($anchor.attr('href')).offset().top)
            }, 1000, 'easeInOutExpo');
            e.preventDefault();
        });



        // 初始化
        const menu = $("#left-menu");
        const overlay = $(".overlay");
        const toggleBtn = $(".show-nav");
        overlay.css({ opacity: 0.06, display: "none" });

        // 切换菜单
        toggleBtn.click(function() {
            $('#content').addClass('toright')
            $('#left-menu').addClass('toright')
            overlay.show();
        });

        // 点击遮罩层关闭菜单
        overlay.click(function() {
            $('#content').removeClass('toright')
            $('#left-menu').removeClass('toright')
            overlay.hide();
        });

    });
</script>
</body>
</html>