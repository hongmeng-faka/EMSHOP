<?php defined('EM_ROOT') || exit('access denied!'); ?>


<div class="layui-tabs" style="margin-bottom: 12px;" lay-options="{trigger: false}">
    <ul class="layui-tabs-header">
        <li><a href="./setting.php">基础设置</a></li>
        <li><a href="./setting.php?action=user">用户设置</a></li>
        <li><a href="./setting.php?action=seo">SEO设置</a></li>
        <li><a href="./setting.php?action=mail">邮箱配置</a></li>
        <li><a href="./blogger.php">个人信息</a></li>
        <li class="layui-this"><a href="?action=setting">分站配置</a></li>
    </ul>
</div>
<div class="layui-panel">
    <div style="padding: 20px;">
        <form action="?action=setting_save" method="post" name="setting_form" id="setting_form" class="layui-form">
            <div class="layui-form-item">
                <label class="layui-form-label">分站使用域名</label>
                <div class="layui-input-block">
                    <textarea class="layui-textarea" name="station_domain" placeholder="多个域名请使用回车换行"><?= $station_domain ?></textarea>
                    <span class="form-tips">分站配置二级域名时选择的域名后缀</span>
                </div>
            </div>

            <div class="layui-form-item">
                <label class="layui-form-label">CNAME解析域名</label>
                <div class="layui-input-block">
                    <input type="text" name="station_cname_domain" class="layui-input" value="<?= $station_cname_domain ?>" />
                    <span class="form-tips">分站配置独立域名时的CNAME解析域名</span>
                </div>
            </div>


            <input name="token" id="token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button type="submit" class="layui-btn" lay-submit lay-filter="demo1">保存设置</button>
                    <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                </div>
            </div>
        </form>
    </div>
</div>


<script>
    $(function () {
        $("#menu-system").attr('class', 'admin-menu-item has-list in');
        $("#menu-system .fa-angle-right").attr('class', 'admin-arrow fa fa-angle-right active');
        $("#menu-system > .submenu").css('display', 'block');
        $('#menu-setting > a').attr('class', 'menu-link active')

        // 提交表单
        $("#setting_form").submit(function (event) {
            event.preventDefault();
            submitForm("#setting_form");
        });
    });
</script>
