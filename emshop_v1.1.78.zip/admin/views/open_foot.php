<?php doAction('open_footer') ?>
</body>
</html>

