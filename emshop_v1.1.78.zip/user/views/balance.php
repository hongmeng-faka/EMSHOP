<?php
defined('EM_ROOT') || exit('access denied!');
$payment = getPayment();

?>
<link rel="stylesheet" href="<?= EM_URL ?>/user/views/test/css/balance.css">
<link rel="stylesheet" href="<?= EM_URL ?>/user/views/test/css/modal_styles.css">
<link rel="stylesheet" href="<?= EM_URL ?>/user/views/test/css/recharge_styles.css">
<!-- 主内容区 -->
<main class="main-content">
    <!-- 余额卡片 -->
    <div class="card balance-card">
        <div class="balance-title">当前可用余额</div>
        <div class="balance-amount">¥ <?= $user['money'] ?></div>
        <div class="balance-actions">
            <button class="balance-btn em-modal" data-modal="recharge-modal">
                充值余额
            </button>
            <span class="balance-btn em-modal" data-modal="withdraw-modal">
                余额提现
            </span>
        </div>
    </div>

    <div class="layui-panel">
        <table class="layui-hide" id="index" lay-filter="index"></table>
        <script type="text/html" id="money">
            <div class="">
                {{# if(d.plus == 'y'){ }}
                <div><span class="layui-badge layui-bg-blue">+ {{ d.money }}</span></div>
                {{#  } }}
                {{# if(d.plus == 'n'){ }}
                <div><span class="layui-badge layui-bg-cyan">- {{ d.money }}</span></div>
                {{#  } }}
            </div>
        </script>
    </div>

</main>

<!-- 充值 -->
<div id="recharge-modal" class="modal-wrapper" style="display: none;">
    <div class="modal-content">
        <div class="modal-close close-modal-btn" data-modal="recharge-modal">
            <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" fill="currentColor"/></svg>
        </div>
        <div class="modal-header">
            <div class="modal-title">余额充值</div>
            <!-- <div class="modal-desc">付款后，余额将会自动到达您的账户。如未到账，请联系客服人员处理。</div> -->
        </div>
        <div class="modal-body">
            <form class="layui-form modal-form" id="recharge-form">
                <div class="layui-form-item">
                    <label class="layui-form-label">充值金额</label>
                    <div class="layui-input-block">
                        <!-- 快捷金额选择 -->
                        <div class="amount-quick-select">
                            <div class="amount-item active" data-amount="100">
                                <span class="amount-symbol">¥</span>
                                <span class="amount-value">100</span>
                            </div>
                            <div class="amount-item" data-amount="200">
                                <span class="amount-symbol">¥</span>
                                <span class="amount-value">200</span>
                            </div>
                            <div class="amount-item" data-amount="500">
                                <span class="amount-symbol">¥</span>
                                <span class="amount-value">500</span>
                            </div>
                            <div class="amount-item" data-amount="1000">
                                <span class="amount-symbol">¥</span>
                                <span class="amount-value">1000</span>
                            </div>
                            <div class="amount-item custom-amount" data-amount="custom">
                                <span class="amount-symbol">¥</span>
                                <span class="amount-value">自定义</span>
                            </div>
                        </div>
                        
                        <!-- 自定义金额输入框 -->
                        <div class="custom-amount-input" style="display: none;">
                            <input type="number" value="100" name="amount" placeholder="请输入自定义金额" class="layui-input" min="1">
                        </div>
                        
                        <div class="form-hint">最低充值金额：¥ 10.00</div>
                    </div>
                </div>
                
                <div class="layui-form-item">
                    <label class="layui-form-label">充值方式</label>
                    <div class="layui-input-block">
                        <div class="payment-methods">
                            <?php foreach($payment as $key => $val): ?>
                                <?php if($val['plugin_name'] == 'balance') continue; ?>
                                <div class="payment-method-item <?= $key == 0 ? 'active' : '' ?>" data-method="<?= $val['plugin_name'] ?>">
                                    <div class="payment-icon">
                                        <img src="../<?= $val['icon'] ?>" alt="<?= $val['title'] ?>">
                                    </div>
                                    <div class="payment-info">
                                        <div class="payment-name"><?= $val['title'] ?></div>
                                        <div class="payment-desc">安全快捷支付</div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="method" value="<?= $payment[0]['plugin_name'] ?>">
                    </div>
                </div>
                <input name="token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
            </form>
        </div>
        <div class="modal-form-actions">
            <button type="submit" class="btn submit-btn" lay-submit lay-filter="recharge-submit">
                <i class="fa fa-check"></i>
                立即提交
            </button>
            <button type="button" class="btn cancel-btn close-modal-btn" data-modal="recharge-modal">
                <i class="fa fa-times"></i>
                取消
            </button>
        </div>
    </div>
</div>

<!-- 提现 -->
<div id="withdraw-modal" class="modal-wrapper" style="display: none;">
    <div class="modal-content">
        <div class="modal-close close-modal-btn" data-modal="withdraw-modal">
            <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" fill="currentColor"/></svg>
        </div>
        <div class="modal-header">
            <div class="modal-title">余额提现申请</div>
            <div class="modal-desc">填写您的提现信息，我们将尽快处理您的申请</div>
        </div>
        <div class="modal-body">
            <form class="layui-form modal-form" id="withdraw-form">
                <div class="layui-form-item">
                    <label class="layui-form-label">提现金额</label>
                    <div class="layui-input-block">
                        <input type="number" name="amount" placeholder="请输入提现金额" class="layui-input">
                        <div class="form-hint">可提现余额：¥ <?= $user['money'] ?></div>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">提现方式</label>
                    <div class="layui-input-block">
                        <select name="method">
                            <option value="">请选择提现方式</option>
                            <option value="alipay">支付宝</option>
                            <option value="wechat">微信</option>
                            <option value="bank">银行卡</option>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">账户信息</label>
                    <div class="layui-input-block">
                        <input type="text" name="account" placeholder="请输入提现账户" class="layui-input">
                        <div class="form-hint">请输入支付宝账号/微信号/银行卡号</div>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">真实姓名</label>
                    <div class="layui-input-block">
                        <input type="text" name="realname" placeholder="请输入真实姓名" class="layui-input">
                        <div class="form-hint">请输入与提现账户对应的真实姓名</div>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">备注说明</label>
                    <div class="layui-input-block">
                        <textarea name="remark" placeholder="请输入备注说明（选填）" class="layui-textarea" rows="3"></textarea>
                    </div>
                </div>
                <input name="token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
            </form>
        </div>
        <div class="modal-form-actions">
            <button type="submit" class="btn submit-btn" lay-submit lay-filter="withdraw-submit">
                <i class="fa fa-check"></i>
                立即提交
            </button>
            <button type="button" class="btn cancel-btn close-modal-btn" data-modal="withdraw-modal">
                <i class="fa fa-times"></i>
                取消
            </button>
        </div>
    </div>
</div>

<script>
    $(function(){
        // 快捷金额选择
        $('.amount-item').on('click', function() {
            $('.amount-item').removeClass('active');
            $(this).addClass('active');
            
            var amount = $(this).data('amount');
            var $customInput = $('.custom-amount-input');
            var $amountInput = $('input[name="amount"]');
            
            if (amount === 'custom') {
                // 显示自定义金额输入框
                $customInput.slideDown(300);
                $amountInput.focus();
                $selectedAmount.val('custom');
            } else {
                // 隐藏自定义金额输入框并设置快捷金额
                $customInput.slideUp(300);
                $amountInput.val(amount);
                $selectedAmount.val(amount);
            }
        });
        

        
        // 支付方式选择
        $('.payment-method-item').on('click', function() {
            $('.payment-method-item').removeClass('active');
            $(this).addClass('active');
            
            var method = $(this).data('method');
            $('input[name="method"]').val(method);
        });
    })
</script>


<script>
    // 初始化Layui模块
    layui.use(['element', 'layer'], function() {
        var table = layui.table;
        var form = layui.form;
        var layer = layui.layer;
// 创建渲染实例
        window.table = table.render({
            elem: '#index',
            autoSort: false,
            url: '?action=index', // 此处为静态模拟数据，实际使用时需换成真实接口
            toolbar: '#toolbar',
            limits: [10,20,30,50,100,200,500,1000],
            page: true,
            lineStyle: 'height: 50px;',
            defaultToolbar: ['filter', 'exports'],


            cols: [[
                {field:'description', title: '说明', minWidth: 180, height: 50},
                {field:'money', title:'更新金额', minWidth: 130, templet: '#money', height: 50},
                {field:'update_before', title:'更新前的余额', minWidth: 130, height: 50},
                {field:'create_time', title:'更新时间', minWidth: 180, height: 50},
            ]],

            error: function(res, msg){
                console.log(res, msg)
            }
        });



        
        

        
        // 提现表单提交
        layui.use(['form'], function() {
            var form = layui.form;

            form.on('submit(recharge-submit)', function(data) {
                var formData = $('#recharge-form').serialize();
                // 提交数据
                $.ajax({
                    type: "POST",
                    url: "?action=recharge",
                    data: formData,
                    dataType: "json",
                    beforeSend: function() {
                        layer.load(2);
                    },
                    success: function (e) {
                        layer.closeAll('loading');
                        if(e.code == 400){
                            return layer.msg(e.msg);
                        }
                        // 跳转支付页面
                        location.href="<?= EM_URL ?>?action=pay&out_trade_no=" + e.data.out_trade_no;
                    },
                    error: function (xhr) {
                        layer.closeAll('loading');
                        try {
                            var errorData = JSON.parse(xhr.responseText);
                            layer.msg(errorData.msg || '提交失败，请重试');
                        } catch (e) {
                            layer.msg('网络错误，请重试');
                        }
                    }
                });
                return false;
            });
            
            form.on('submit(withdraw-submit)', function(data) {
                var formData = $('#withdraw-form').serialize();
                // 提交数据
                $.ajax({
                    type: "POST",
                    url: "?action=withdraw_ajax",
                    data: formData,
                    dataType: "json",
                    beforeSend: function() {
                        layer.load(2);
                    },
                    success: function (e) {
                        layer.closeAll('loading');
                        if(e.code == 400){
                            return layer.msg(e.msg);
                        }
                        hideEmModal('withdraw-modal');
                        layer.msg('提现申请已提交');
                        // 刷新页面数据
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    },
                    error: function (xhr) {
                        layer.closeAll('loading');
                        try {
                            var errorData = JSON.parse(xhr.responseText);
                            layer.msg(errorData.msg || '提交失败，请重试');
                        } catch (e) {
                            layer.msg('网络错误，请重试');
                        }
                    }
                });
                return false;
            });
        });

        // 工具栏事件
        table.on('toolbar(index)', function(obj){
            var id = obj.config.id;
            var checkStatus = table.checkStatus(id);
            var othis = lay(this);
            if(obj.event == 'refresh'){
                table.reload(id);
            }

           



        });

        // 触发单元格工具事件
        table.on('tool(index)', function(obj){ // 双击 toolDouble
            var data = obj.data; // 获得当前行数据
            var id = obj.config.id;


            if(obj.event === 'img'){
                layer.photos({
                    photos: {
                        "title": data.title,
                        "start": 0,
                        "data": [
                            {
                                "alt": data.title,
                                "pid": 1,
                                "src": data.cover,
                            }
                        ]
                    }
                });
            }
            if(obj.event === 'edit'){
                let isMobile = window.innerWidth < 768;
                let area = isMobile ? ['98%', 'auto']  : ['700px', 'auto'];
                layer.open({
                    id: 'edit',
                    title: '编辑',
                    type: 2,
                    area: area,
                    skin: 'layui-layer-molv',
                    content: '?action=master_goods_edit&goods_id=' + data.id,
                    fixed: false, // 不固定
                    maxmin: true,
                    shadeClose: true,
                    success: function(layero, index, that){
                        layer.iframeAuto(index); // 让 iframe 高度自适应
                        that.offset(); // 重新自适应弹层坐标
                    }
                });
            }
        });

// 触发表格复选框选择
        table.on('checkbox(index)', function(obj){
            var id = obj.config.id;
            var checkData = table.checkStatus(id).data;
            console.log(checkData)
            if(checkData.length == 0){
                $('.toolbar-select').addClass('layui-btn-disabled');
            }else{
                $('.toolbar-select').removeClass('layui-btn-disabled');
            }
        });

    });
</script>

<script>
    $('#menu-balance').addClass('open');
    $('#menu-balance > ul').css('display', 'block');
    $('#menu-balance > a > i.nav_right').attr('class', 'fa fa-angle-down nav_right');
    $('#menu-balance-index').addClass('menu-current');
</script>