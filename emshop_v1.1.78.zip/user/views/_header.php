<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>个人中心 - <?= Option::get('blogname') ?></title>
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link href="<?= empty(Option::get('personal_center_icon')) ? '../admin/views/images/favicon.ico' : Option::get('personal_center_icon'); ?>" rel="shortcut icon">


    <script src="<?= EM_URL ?>/admin/views/js/jquery.min.3.5.1.js"></script>
    <link rel="stylesheet" href="<?= EM_URL ?>/admin/views/layui-v2.11.6/layui/css/layui.css">
    <script src="<?= EM_URL ?>/admin/views/layui-v2.11.6/layui/layui.js"></script>
    <script src="<?= EM_URL ?>/admin/views/components/clipboard.min.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>

    <link rel="stylesheet" type="text/css" href="<?= EM_URL ?>/admin/views/font-awesome-4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?= EM_URL ?>/user/views/test/css/xadmin.css">
    <link rel="stylesheet" href="<?= EM_URL ?>/content/static/css/em.css">

    <script type="text/javascript" src="<?= EM_URL ?>/user/views/test/js/xadmin.js"></script>

    
    

    <style>
        body{
            background: #f8f8f8;
        }
        .body-page{
            max-width: 1500px;
            height: 100%;
            position: absolute;
            height: auto;
            display: block;
            top: 10px;
            bottom: 10px;
            left: 0;
            right: 0;
            margin: 0 auto;
            border-radius: 10px;
        }
        .container{
            position: absolute;
            left: 230px;
            height: 59px;
            background: #41444B;
            width: auto;
            right: 10px;
            z-index: 100;
            border-radius: 10px;
        }
        .left-nav{
            top: 0px;
        }
        .layui-nav .layui-nav-item a{
            padding: 5px 20px;
        }
        .layui-nav .layui-nav-item{
            margin-right: 12px;
        }
        .layui-nav .layui-nav-item:last-of-type{
            margin-right: 0px;
        }
        .layui-nav{
            padding-right: 20px;
        }

        .layui-nav .layui-nav-more{
            top: 9px;
        }

        .logo-text{
            color: #f8f8f8;
            text-align: center;
            font-size: 21px;
            padding: 5px 0 10px 0;
            border-bottom: 1px solid #3f3f3f;
            display: block;
        }
        .left_open{
            padding-left: 12px;
            display: none;
        }
        .left-nav #nav li a{
            color: #c4c4c4;
        }
        .page-content{
            top: 60px;
        }
        @media screen and (max-width: 768px) {
            .container {
                left: 0px;
            }
            .left_open{
                display: block;
            }
            .body-page{
                top: 0;
                bottom: 0;
            }
        }
        .main-content{
            padding: 20px 15px;
        }
    </style>

</head>
<body>

<div class="body-page">


<!-- 顶部开始 -->
<div class="container">
    <div class="left_open">
        <i title="展开左侧栏" class="fa fa-bars"></i>
    </div>

    <ul class="layui-nav right" lay-filter="">
        <li class="layui-nav-item">
            <a href="<?= EM_URL ?>">前台首页<span class="layui-badge-dot"></span></a>
        </li>
        <?php if(Option::get('login_switch') == 'y' && Option::get('register_switch') == 'y'): ?>
        <li class="layui-nav-item" lay-unselect>
            <a href="javascript:;">
                <img src="https://unpkg.com/outeres@0.0.10/demo/avatar/1.jpg" class="layui-nav-img">
            </a>
            <dl class="layui-nav-child">
<!--                <dd><a href="javascript:;">个人信息</a></dd>-->
                <dd><a href="/user/account.php?action=logout">退出登录</a></dd>
            </dl>
        </li>
        <?php endif; ?>
    </ul>

</div>
<!-- 顶部结束 -->
<!-- 中部开始 -->
<!-- 左侧菜单开始 -->
<div class="left-nav">
    <a href="<?= EM_URL ?>" class="logo-text"><?= Option::get('blogname') ?></a>
    <div id="side-nav">
        <ul id="nav">
            <li id="menu-index">
                <a href="/user"><i class="fa fa-user"></i><cite>个人中心</cite></a>
            </li>

            <li id="menu-balance">
                <a href="javascript:;">
                    <i class="fa fa-yen"></i>
                    <cite>我的账单</cite>
                    <i class="fa fa-angle-right nav_right"></i>
                </a>
                <ul class="sub-menu">
                    <li id="menu-balance-index"><a href="/user/balance.php"><i class="fa fa-search"></i><cite>我的余额</cite></a></li>
                    <li id="menu-balance-withdraw"><a href="/user/balance.php?action=withdraw_index"><i class="fa fa-list-ul"></i><cite>提现记录</cite></a></li>
                </ul>
            </li>
            <li id="menu-order">
                <a href="javascript:;">
                    <i class="fa fa-list-ul"></i>
                    <cite>我的订单</cite>
                    <i class="fa fa-angle-right nav_right"></i>
                </a>
                <ul class="sub-menu">
                    <li id="menu-order-visitors"><a href="/user/visitors.php"><i class="fa fa-search"></i><cite>游客查单</cite></a></li>
                    <li id="menu-order-user"><a href="/user/order.php"><i class="fa fa-list-ul"></i><cite>订单列表</cite></a></li>
                </ul>
            </li>
            <li id="menu-open-station">
                <a href="/user/station.php?action=open"><i class="fa fa-sitemap"></i><cite>开通分站</cite></a>
            </li>
            <?php if(empty($userData['station'])): ?>

            <?php else: ?>
                <li id="menu-station">
                    <a href="javascript:;">
                        <i class="fa fa-list-ul"></i>
                        <cite>我的店铺</cite>
                        <i class="fa fa-angle-right nav_right"></i>
                    </a>
                    <ul class="sub-menu">
                        <li id="menu-station-index"><a href="/user/station.php"><i class="fa fa-search"></i><cite>店铺概览</cite></a></li>
                        <li id="menu-station-setting"><a href="/user/station.php?action=setting"><i class="fa fa-list-ul"></i><cite>店铺配置</cite></a></li>
<!--                        <li id="menu-station-user"><a href="/user/order.php"><i class="fa fa-list-ul"></i><cite>自营商品</cite></a></li>-->
<!--                        <li id="menu-station-user"><a href="/user/order.php"><i class="fa fa-list-ul"></i><cite>自营分类</cite></a></li>-->
                        <li id="menu-station-master_goods"><a href="/user/station.php?action=master_goods"><i class="fa fa-list-ul"></i><cite>主站商品</cite></a></li>
                        <li id="menu-station-master_sort"><a href="/user/station.php?action=master_sort"><i class="fa fa-list-ul"></i><cite>主站分类</cite></a></li>
                        <li id="menu-station-order"><a href="/user/station.php?action=order"><i class="fa fa-list-ul"></i><cite>商品订单</cite></a></li>
                    </ul>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<!-- <div class="x-slide_left"></div> -->
<!-- 左侧菜单结束 -->
<!-- 右侧主体开始 -->
<div class="page-content">
    <div class="layui-tab tab" lay-filter="xbs_tab" lay-allowclose="false">

        <div class="layui-tab-content">
            <div class="layui-tab-item layui-show" style=" background: #f8f8f8;">
