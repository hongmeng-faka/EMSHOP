</div>
</div>
</div>
</div>

<div class="page-content-bg"></div>
</div
<!-- 右侧主体结束 -->
<!-- 中部结束 -->
<!-- 底部开始 -->
<!--<div class="footer">
    <div class="copyright">Copyright ©2019 L-admin v2.3 All Rights Reserved</div>
</div>-->
<!-- 底部结束 -->
 <script src="<?= EM_URL ?>/content/static/js/em.js?t=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>
<?php doAction('user_footer') ?>
</body>
</html>