<?php
/**
 * The productf management
 *
 * @package EMLOG
 * @link https://www.emlog.net
 */

/**
 * @var string $action
 * @var object $CACHE
 */

require_once 'globals.php';
//require_once '../init.php';

$orderModel = new Order_Model();
$Sort_Model = new Sort_Model();
$User_Model = new User_Model();
$MediaSort_Model = new MediaSort_Model();
$Template_Model = new Template_Model();

$sta_cache = $CACHE->readCache('sta');
$user_cache = $CACHE->readCache('user');
$action = Input::getStrVar('action');

$db = Database::getInstance();
$db_prefix = DB_PREFIX;


if (empty($action)) {
    $db = Database::getInstance();
    $db_prefix = DB_PREFIX;
    global $userData;

    $station_id = $userData['station']['id'];
    $level_id = $userData['station']['level_id'];

    $station = $db->once_fetch_array("select * from {$db_prefix}station_level where id = {$level_id}");

    
    // 获取订单统计数据

    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    $month_start = date('Y-m-01');
    
    // 今日订单数和金额
    $today_sql = "SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as amount FROM {$db_prefix}order 
                  WHERE station_id = {$station_id} AND pay_time IS NOT NULL 
                  AND DATE(FROM_UNIXTIME(pay_time)) = '{$today}'";
    $today_data = $db->once_fetch_array($today_sql);
    $today_orders = $today_data['count'];
    $today_amount = $today_data['amount'] / 100; // 转换为元
    
    // 昨日订单数和金额
    $yesterday_sql = "SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as amount FROM {$db_prefix}order 
                      WHERE station_id = {$station_id} AND pay_time IS NOT NULL 
                      AND DATE(FROM_UNIXTIME(pay_time)) = '{$yesterday}'";
    $yesterday_data = $db->once_fetch_array($yesterday_sql);
    $yesterday_orders = $yesterday_data['count'];
    $yesterday_amount = $yesterday_data['amount'] / 100; // 转换为元
    
    // 本月订单数和金额
    $month_sql = "SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as amount FROM {$db_prefix}order 
                  WHERE station_id = {$station_id} AND pay_time IS NOT NULL 
                  AND DATE(FROM_UNIXTIME(pay_time)) >= '{$month_start}'";
    $month_data = $db->once_fetch_array($month_sql);
    $month_orders = $month_data['count'];
    $month_amount = $month_data['amount'] / 100; // 转换为元
    
    // 总订单数和金额
    $total_sql = "SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as amount FROM {$db_prefix}order 
                  WHERE station_id = {$station_id} AND pay_time IS NOT NULL";
    $total_data = $db->once_fetch_array($total_sql);
    $total_orders = $total_data['count'];
    $total_amount = $total_data['amount'] / 100; // 转换为元
    
    // 用户注册统计数据
    // 今日注册用户数
    $today_user_sql = "SELECT COUNT(*) as count FROM {$db_prefix}user 
                       WHERE station_id = {$station_id} 
                       AND DATE(FROM_UNIXTIME(create_time)) = '{$today}'";
    $today_user_data = $db->once_fetch_array($today_user_sql);
    $today_users = $today_user_data['count'];
    
    // 昨日注册用户数
    $yesterday_user_sql = "SELECT COUNT(*) as count FROM {$db_prefix}user 
                           WHERE station_id = {$station_id} 
                           AND DATE(FROM_UNIXTIME(create_time)) = '{$yesterday}'";
    $yesterday_user_data = $db->once_fetch_array($yesterday_user_sql);
    $yesterday_users = $yesterday_user_data['count'];
    
    // 本月注册用户数
    $month_user_sql = "SELECT COUNT(*) as count FROM {$db_prefix}user 
                       WHERE station_id = {$station_id} 
                       AND DATE(FROM_UNIXTIME(create_time)) >= '{$month_start}'";
    $month_user_data = $db->once_fetch_array($month_user_sql);
    $month_users = $month_user_data['count'];
    
    // 总注册用户数
    $total_user_sql = "SELECT COUNT(*) as count FROM {$db_prefix}user 
                       WHERE station_id = {$station_id}";
    $total_user_data = $db->once_fetch_array($total_user_sql);
    $total_users = $total_user_data['count'];

    include View::getUserView('_header');
    require_once View::getUserView('station/index');
    include View::getUserView('_footer');
    View::output();
}

if ($action == 'setting') {
    $sql = "select * from {$db_prefix}station_level where id = {$userData['station']['level_id']}";
    $station = $db->once_fetch_array($sql);
    $userStation = $userData['station'];

    $options_cache = $CACHE->readCache('options');
    $station_domain = isset($options_cache['station_domain']) ? $options_cache['station_domain'] : '';
    $station_domain = preg_split("/\r?\n/", $station_domain);

    include View::getUserView('_header');
    require_once View::getUserView('station/setting');
    include View::getUserView('_footer');
    View::output();
}

if ($action == 'setting_tpl') {
    $sql = "select * from {$db_prefix}station_level where id = {$userData['station']['level_id']}";
    $station = $db->once_fetch_array($sql);
    $userStation = $userData['station'];

    $options_cache = $CACHE->readCache('options');
    $station_domain = isset($options_cache['station_domain']) ? $options_cache['station_domain'] : '';
    $station_domain = preg_split("/\r?\n/", $station_domain);

    include View::getUserView('_header');
    require_once View::getUserView('station/setting_tpl');
    include View::getUserView('_footer');
    View::output();
}
if ($action == 'store_tpl') {
    $sql = "select * from {$db_prefix}station_level where id = {$userData['station']['level_id']}";
    $station = $db->once_fetch_array($sql);
    $userStation = $userData['station'];

    $options_cache = $CACHE->readCache('options');
    $station_domain = isset($options_cache['station_domain']) ? $options_cache['station_domain'] : '';
    $station_domain = preg_split("/\r?\n/", $station_domain);

    include View::getUserView('_header');
    require_once View::getUserView('station/store_tpl');
    include View::getUserView('_footer');
    View::output();
}
if($action == 'store_tpl_ajax'){
    $tag = Input::getStrVar('tag');
    $page = Input::getIntVar('page', 1);
    $keyword = Input::getStrVar('keyword');
    $author_id = Input::getStrVar('author_id');
    $sid = Input::getStrVar('sid');

    global $userData;

//    d($userData);die;

    $Store_Model = new Store_Model();
    $r = $Store_Model->getStationTemplates($tag, $keyword, $page, $author_id, $sid, $userData['station']['station_unique']);

    $Plugin_Model = new Plugin_Model();
    $p = $Plugin_Model->getPlugins();
    $install_plugin = [];
    foreach($p as $val){
        $install_plugin[] = $val['Plugin'];
    }

    $Template_Model = new Template_Model();

    $p = $Template_Model->getStationTemplates($userData);
    foreach($p as $val){
        $install_plugin[] = $val['tplfile'];
    }

    $apps = $r['templates'];
    $count = $r['count'];
    $page_count = $r['page_count'];

    $reg_type = Register::getRegType();

    $sql = "select * from {$db_prefix}authorization where type < 3 order by type desc";
    $res = $db->once_fetch_array($sql);
    $reg_type =  empty($res) ? false : $res['type'];



    foreach($apps as $key => $val){
        $apps[$key]['reg_type'] = $reg_type;
        if(in_array($val['english_name'], $install_plugin)){
            $apps[$key]['is_install'] = 'y';
        }else{
            $apps[$key]['is_install'] = 'n';
        }
    }

    output::data($apps, $count);
}
if($action == 'get_tpl'){
    $db = Database::getInstance();
    $db_prefix = DB_PREFIX;
    $station = $userData['station'];




    $userTpl = $db->fetch_all("select * from {$db_prefix}station_plugin where station_id={$station['id']} and type = 'tpl'");
    if(empty($userTpl)){
        $userTpl = [
            [
                'station_id' => $station['id'],
                'plugin_name_cn' => '默认模板',
                'plugin_name_en' => 'default',
                'type' => 'tpl',
                'pc_switch' => 'y',
                'tel_switch' => 'y',
            ]
        ];
        $db->add('station_plugin', $userTpl[0]);
    }

    $list = $Template_Model->getStationTemplates($userData);

    $station_plugin_pc = $db->once_fetch_array("select * from {$db_prefix}station_plugin where station_id={$station['id']} and type='tpl' and pc_switch = 'y'");
    $station_plugin_tel = $db->once_fetch_array("select * from {$db_prefix}station_plugin where station_id={$station['id']} and type='tpl' and tel_switch = 'y'");



    $nonce_template = empty($station_plugin_pc) ? 'default' : $station_plugin_pc['plugin_name_en'];
    $nonce_template_tel = empty($station_plugin_tel) ? 'default' : $station_plugin_tel['plugin_name_en'];
    $nonce_template_data = @file(TPLS_STATION_PATH . $nonce_template . '/header.php');




    $post_data = [
        'station_unique' => $station['station_unique'],
        'apps'  => [],
    ];

    foreach($list as $key => $val){
        if($nonce_template == $val['tplfile']){
            $list[$key]['switch'] = 'y';
        }else{
            $list[$key]['switch'] = 'n';
        }
        if($nonce_template_tel == $val['tplfile']){
            $list[$key]['tel_switch'] = 'y';
        }else{
            $list[$key]['tel_switch'] = 'n';
        }
        $post_data['apps'][] = [
            'name' => $val['tplfile'],
            'version' => $val['version']
        ];
    }
    $post_data['apps'] = json_encode($post_data['apps']);


    $emcurl = new EmCurl();
    $emcurl->setPost($post_data);
    $emcurl->request(EM_LINE[CURRENT_LINE]['value'] . 'api/template/upgrade');
    $retStatus = $emcurl->getHttpStatus();
    $update_data = [];
    if ($retStatus !== MSGCODE_SUCCESS) {
//        Output::error('请求更新失败，可能是网络问题');
    }
    $response = $emcurl->getRespone();
    $ret = json_decode($response, 1);
    if (empty($ret)) {
//        Output::error('请求更新失败，可能是网络问题');
    }
    if ($ret['code'] === MSGCODE_EMKEY_INVALID) {
//        Output::error('未注册的pro版本');
    }
    if($ret['code'] == 200){
        $update_data = $ret['data'];
    }
//    d($ret);die;

    foreach($list as $key => $val){
        $list[$key]['update'] = 'n';
        foreach($update_data as $k => $v){
            if($v['name'] == $val['tplfile']){
                $list[$key]['update'] = 'y';
            }
        }
    }


    output::data($list, count($list));
}

if ($action === 'upgrade') {
    $alias = isset($_GET['alias']) ? trim($_GET['alias']) : '';

    $alias = Input::postStrVar('alias');



    $url = EM_LINE[CURRENT_LINE]['value'] . 'api/template/down?plugin=' . $alias;
    $temp_file = emFetchFile($url);
    if (!$temp_file) {
        Ret::error('更新文件路径错误');
    }
    $unzip_path = '../content/station_templates/';
    $ret = emUnZip($temp_file, $unzip_path, 'tpl');
    @unlink($temp_file);
    switch ($ret) {
        case 0:
            $Template_Model->upCallback($alias);
            output::ok();
            break;
        case 1:
        case 2:
            output::error('更新失败');
            break;
        case 3:
            output::error('更新失败');
            break;
        default:
            output::error('更新失败');
    }
}

if($action == 'use'){ // 启用模板
    global $userData;
    $db = Database::getInstance();
    $update = [
        'pc_switch' => 'n'
    ];
    $db->update('station_plugin', $update, [
        'station_id' => $userData['station']['id'],
        'type' => 'tpl'
    ]);
    $status = Input::postStrVar('status');
    if($status == 1){
        $update = [
            'pc_switch' => 'y'
        ];
        $tpl = Input::postStrVar('tpl');
        $db->update('station_plugin', $update, [
            'station_id' => $userData['station']['id'],
            'type' => 'tpl',
            'plugin_name_en' => $tpl
        ]);
    }

    Ret::success('操作成功');
}

if($action == 'use_tel'){ // 启用模板
    global $userData;
    $db = Database::getInstance();
    $update = [
        'tel_switch' => 'n'
    ];
    $db->update('station_plugin', $update, [
        'station_id' => $userData['station']['id'],
        'type' => 'tpl'
    ]);
    $status = Input::postStrVar('status');
    if($status == 1){
        $update = [
            'tel_switch' => 'y'
        ];
        $tpl = Input::postStrVar('tpl');
        $db->update('station_plugin', $update, [
            'station_id' => $userData['station']['id'],
            'type' => 'tpl',
            'plugin_name_en' => $tpl
        ]);
    }

    Ret::success('操作成功');
}





if ($action == 'master_sort') {
    include View::getUserView('_header');
    require_once View::getUserView('station/master_sort');
    include View::getUserView('_footer');
    View::output();
}
if ($action == 'master_goods') {
    include View::getUserView('_header');
    require_once View::getUserView('station/master_goods');
    include View::getUserView('_footer');
    View::output();
}
if($action == 'master_goods_index'){
    $page_num = Input::getIntVar('limit');
    $page = Input::getIntVar('page');
    $start = ($page - 1) * $page_num;
    $sql = "select g.id, g.title, sg.custom_name, sg.is_show, sg.premium from {$db_prefix}goods g  
         left join {$db_prefix}station_goods sg on g.id=sg.goods_id 
         where g.is_on_shelf=1 and g.delete_time is null and g.station_id=0 order by g.id desc
         limit $start, $page_num";
    $list = $db->fetch_all($sql);
    foreach($list as &$val){
        $val['premium'] = $val['premium'] === null ? '10' : $val['premium'] * 100;
    }
    $sql = "select count(g.id) total from {$db_prefix}goods g  
         left join {$db_prefix}station_goods sg on g.id=sg.goods_id 
         where g.is_on_shelf=1 and g.delete_time is null and g.station_id=0";
    $res = $db->once_fetch_array($sql);
    output::data($list, $res['total']);
}
if ($action == 'order') {
    include View::getUserView('_header');
    require_once View::getUserView('station/order');
    include View::getUserView('_footer');
    View::output();
}
if($action == 'order_index'){
    $station_id = $userData['station']['id'];
    $page = Input::getIntVar('page', 1);
    $limit = Input::getIntVar('limit', 10);
    $start = ($page - 1) * $limit;
    $sort1 = Input::getStrVar('field', 'uid');
    $sort2 = Input::getStrVar('order', 'desc');
    $order_by = "order by {$sort1} {$sort2}";


    $where  = [];
    $where['email_username'] = Input::getStrVar('email_username');
    $where['out_trade_no'] = Input::getStrVar('out_trade_no');
    $where['goods_title'] = Input::getStrVar('goods_title');
    $where['client_ip'] = Input::getStrVar('client_ip');
    $where['order_required'] = Input::getStrVar('order_required');
    $where['station_id'] = $station_id;

    $orderNum = $orderModel->getOrderNum($where);
    $order = $orderModel->getOrderForAdmin($start, $limit, $where);
    foreach($order as $key => $val){
        $order[$key]['pay_time'] = empty($val['pay_time']) ? '' : date('Y-m-d H:i:s', $val['pay_time']);
        $order[$key]['amount'] = number_format($val['amount'], 2);
    }
    output::data($order, $orderNum);
}
if ($action == 'master_sort_edit') {
    global $userData;
    $station_id = $userData['station']['id'];
    $sort_id = Input::getIntVar('sort_id');
    $sql = "select * from {$db_prefix}station_sort where station_id=$station_id and sort_id=$sort_id";
    $station_sort = $db->once_fetch_array($sql);
    $sort = $db->once_fetch_array("select * from {$db_prefix}sort where sid = $sort_id");
    include View::getUserView('open_head');
    require_once View::getUserView('station/master_sort_edit');
    include View::getUserView('open_foot');
    View::output();
}
if ($action == 'master_goods_edit') {
    global $userData;
    $station_id = $userData['station']['id'];
    $goods_id = Input::getIntVar('goods_id');
    $sql = "select * from {$db_prefix}station_goods where station_id=$station_id and goods_id=$goods_id";
    $station_goods = $db->once_fetch_array($sql);
    $goods = $db->once_fetch_array("select * from {$db_prefix}goods where id = $goods_id");
    include View::getUserView('open_head');
    require_once View::getUserView('station/master_goods_edit');
    include View::getUserView('open_foot');
    View::output();
}
if ($action == 'master_goods_premium') {
    global $userData;
    include View::getUserView('open_head');
    require_once View::getUserView('station/master_goods_premium');
    include View::getUserView('open_foot');
    View::output();
}
if($action == 'master_sort_hide'){
    global $userData;
    $station_id = $userData['station']['id'];
    $ids = Input::postStrVar('ids');
    $sql = "select * from {$db_prefix}station_sort where station_id=$station_id and sort_id in($ids)";
    $station_sort = $db->fetch_all($sql);
    $sql = "select * from {$db_prefix}sort where sid in($ids) and station_id=0";
    $sort = $db->fetch_all($sql);
    foreach($sort as $val){
        $is_exists = false;
        foreach($station_sort as $v){
            if($val['sid'] == $v['sort_id']){
                $is_exists = true;
            }
        }
        if($is_exists){
            $db->update('station_sort', [
                'is_show' => 'n'
            ], ['station_id' => $station_id, 'sort_id' => $val['sid']]);
        }else{
            $db->add('station_sort', [
                'station_id' => $station_id,
                'sort_id' => $val['sid'],
                'type' => 'goods',
                'is_show' => 'n',
            ]);
        }
    }
    Ret::success();
}
if($action == 'master_goods_hide'){
    global $userData;
    $station_id = $userData['station']['id'];
    $ids = Input::postStrVar('ids');
    $sql = "select * from {$db_prefix}station_goods where station_id=$station_id and goods_id in($ids)";
    $station_goods = $db->fetch_all($sql);
    $sql = "select * from {$db_prefix}goods where id in($ids) and station_id=0";
    $goods = $db->fetch_all($sql);
    foreach($goods as $val){
        $is_exists = false;
        foreach($station_goods as $v){
            if($val['id'] == $v['goods_id']){
                $is_exists = true;
            }
        }
        if($is_exists){
            $db->update('station_goods', [
                'is_show' => 'n'
            ], ['station_id' => $station_id, 'goods_id' => $val['id']]);
        }else{
            $db->add('station_goods', [
                'station_id' => $station_id,
                'goods_id' => $val['id'],
                'premium' => 0.1,
                'is_show' => 'n',
            ]);
        }
    }
    Ret::success();
}
if($action == 'master_sort_show'){
    global $userData;
    $station_id = $userData['station']['id'];
    $ids = Input::postStrVar('ids');
    $sql = "select * from {$db_prefix}station_sort where station_id=$station_id and sort_id in($ids)";
    $station_sort = $db->fetch_all($sql);
    $sql = "select * from {$db_prefix}sort where sid in($ids) and station_id=0";
    $sort = $db->fetch_all($sql);
    foreach($sort as $val){
        $is_exists = false;
        foreach($station_sort as $v){
            if($val['sid'] == $v['sort_id']){
                $is_exists = true;
            }
        }
        if($is_exists){
            $db->update('station_sort', [
                'is_show' => 'y'
            ], ['station_id' => $station_id, 'sort_id' => $val['sid']]);
        }else{
            $db->add('station_sort', [
                'station_id' => $station_id,
                'sort_id' => $val['sid'],
                'type' => 'goods',
                'is_show' => 'y',
            ]);
        }
    }
    Ret::success();
}
if($action == 'master_goods_show'){
    global $userData;
    $station_id = $userData['station']['id'];
    $ids = Input::postStrVar('ids');
    $sql = "select * from {$db_prefix}station_goods where station_id=$station_id and goods_id in($ids)";
    $station_goods = $db->fetch_all($sql);
    $sql = "select * from {$db_prefix}goods where id in($ids) and station_id=0";
    $goods = $db->fetch_all($sql);
    foreach($goods as $val){
        $is_exists = false;
        foreach($station_goods as $v){
            if($val['id'] == $v['goods_id']){
                $is_exists = true;
            }
        }
        if($is_exists){
            $db->update('station_goods', [
                'is_show' => 'y'
            ], ['station_id' => $station_id, 'goods_id' => $val['id']]);
        }else{
            $db->add('station_goods', [
                'station_id' => $station_id,
                'goods_id' => $val['id'],
                'premium' => 0.1,
                'is_show' => 'y',
            ]);
        }
    }
    Ret::success();
}
if($action == 'master_goods_premium_ajax'){
    global $userData;
    $station_id = $userData['station']['id'];
    $premium = Input::postStrVar('premium', 0);
    $sql = "select * from {$db_prefix}station_goods where station_id=$station_id";
    $station_goods = $db->fetch_all($sql);
    $sql = "select * from {$db_prefix}goods where station_id=0 and is_on_shelf=1 and delete_time is null";
    $goods = $db->fetch_all($sql);
    foreach($goods as $val){
        $is_exists = false;
        foreach($station_goods as $v){
            if($val['id'] == $v['goods_id']){
                $is_exists = true;
            }
        }
        if($is_exists){
            $db->update('station_goods', [
                'premium' => $premium
            ], ['station_id' => $station_id, 'goods_id' => $val['id']]);
        }else{
            $db->add('station_goods', [
                'station_id' => $station_id,
                'goods_id' => $val['id'],
                'premium' => $premium,
                'is_show' => 'n',
            ]);
        }
    }
    Ret::success();
}
if($action == 'master_sort_edit_ajax'){
    $sort_id = Input::postIntVar('sort_id');
    $custom_name = Input::postStrVar('custom_name');
    global $userData;
    $station_id = $userData['station']['id'];
    $sql = "select * from {$db_prefix}station_sort where station_id=$station_id and sort_id=$sort_id";
    $station_sort = $db->once_fetch_array($sql);
    if($station_sort){
        $db->update('station_sort', [
            'custom_name' => $custom_name
        ], ['id' => $station_sort['id']]);
    }else{
        $db->add('station_sort', [
            'station_id' => $station_id,
            'sort_id' => $sort_id,
            'type' => 'goods',
            'is_show' => 'n',
            'custom_name' => $custom_name
        ]);
    }
    Ret::success();
}
if($action == 'master_goods_edit_ajax'){
    $goods_id = Input::postIntVar('goods_id');
    $custom_name = Input::postStrVar('custom_name');
    $premium = Input::postStrVar('premium', 0);
    global $userData;
    $station_id = $userData['station']['id'];
    $sql = "select * from {$db_prefix}station_goods where station_id=$station_id and goods_id=$goods_id";
    $station_goods = $db->once_fetch_array($sql);
    if($station_goods){
        $db->update('station_goods', [
            'custom_name' => $custom_name,
            'premium' => $premium
        ], ['id' => $station_goods['id']]);
    }else{
        $db->add('station_goods', [
            'station_id' => $station_id,
            'goods_id' => $goods_id,
            'is_show' => 'n',
            'custom_name' => $custom_name,
            'premium' => $premium
        ]);
    }
    Ret::success();
}

if($action == 'master_sort_index'){
    $sql = "select s.*, ss.custom_name, ss.is_show from {$db_prefix}sort s  
         left join {$db_prefix}station_sort ss on s.sid=ss.sort_id 
         where s.type='goods' and s.station_id=0 order by s.taxis desc, s.sid asc";
    $list = $db->fetch_all($sql);
    output::data($list, count($list));
}
if($action == 'master_goods_switch'){
    global $userData;
    $goods_id = Input::postIntVar('id');
    $is_show = Input::postStrVar('is_show');
    $station_id = $userData['station']['id'];
    $sql = "select id from {$db_prefix}station_goods where goods_id=$goods_id and station_id=$station_id";
    $station_sort = $db->once_fetch_array($sql);
    if($station_sort){
        $db->update('station_goods', [
            'is_show' => $is_show
        ], ['id' => $station_sort['id']]);
    }else{
        $db->add('station_goods', [
            'station_id' => $station_id,
            'goods_id' => $goods_id,
            'premium' => 0.1,
            'is_show' => $is_show
        ]);
    }
    Ret::success();
}
if($action == 'master_sort_switch'){
    global $userData;
    $sort_id = Input::postIntVar('id');
    $is_show = Input::postStrVar('is_show');
    $station_id = $userData['station']['id'];
    $sql = "select id from {$db_prefix}station_sort where sort_id=$sort_id and station_id=$station_id";
    $station_sort = $db->once_fetch_array($sql);
    if($station_sort){
        $db->update('station_sort', [
            'is_show' => $is_show
        ], ['id' => $station_sort['id']]);
    }else{
        $db->add('station_sort', [
            'station_id' => $station_id,
            'sort_id' => $sort_id,
            'type' => 'goods',
            'is_show' => $is_show
        ]);
    }
    Ret::success();
}

if($action == 'setting_ajax'){
    $name = Input::postStrVar('name');
    $title = Input::postStrVar('title');
    $master_sort = Input::postIntVar('master_sort');
    $master_goods = Input::postIntVar('master_goods');
    $domain_2_prefix = Input::postStrVar('domain_2_prefix');
    $domain_2_suffix = Input::postStrVar('domain_2_suffix');
    if(!empty($domain_2_prefix)){
        if(empty($domain_2_suffix)){
            Ret::error('主站未配置二级域名后缀，暂无法设置二级域名');
        }else{
            $res = $db->once_fetch_array("select * from {$db_prefix}station where domain_2_prefix != '' and domain_2_prefix is not null and domain_2_prefix = '{$domain_2_prefix}' and domain_2_suffix = '{$domain_2_suffix}' and id != {$userData['station']['id']}");
            if(!empty($res)){
                Ret::error('该二级域名的前缀已被占用，请填写其他前缀或选择其他后缀');
            }
        }

    }


    $domain = Input::postStrVar('domain');
    $roll_notice = Input::postStrVar('roll_notice');
    $home_notice = Input::postStrVar('home_notice');

    $update = [
        'name' => $name,
        'title' => $title,
        'master_sort' => $master_sort,
        'master_goods' => $master_goods,
        'domain_2_prefix' => $domain_2_prefix,
        'domain_2_suffix' => $domain_2_suffix,
        'domain_2' => $domain_2_prefix . $domain_2_suffix,
        'domain' => $domain,
        'roll_notice' => $roll_notice,
        'home_notice' => $home_notice
    ];
    $db->update('station', $update, ['id' => $userData['station']['id']]);
    if($master_sort == 1){

    }
    if($master_goods == 1){

    }

    Ret::success('已保存');
}

if ($action == 'open') {
    $sql = "select * from {$db_prefix}station_level order by id asc";
    $station = $db->fetch_all($sql);

    include View::getUserView('_header');
    require_once View::getUserView('station/open');
    include View::getUserView('_footer');
    View::output();
}
if($action == 'open_ajax'){
    $id = Input::postIntVar('id');
    if(empty($id)){
        Ret::error('参数不合法');
    }
    $station = $db->once_fetch_array("select * from {$db_prefix}station where user_id = " . UID);
    if(!empty($station)){
        Ret::error('您已开通过分站，请勿重复开通');
    }
    $user = $db->once_fetch_array("select * from {$db_prefix}user where uid = " . UID);
    if(empty($user)){
        Ret::error('用户余额查询失败');
    }
    $station_level = $db->once_fetch_array("select * from {$db_prefix}station_level where id = {$id}");
    if(empty($station_level)){
        Ret::error('套餐不存在或已被删除');
    }
    if($user['money'] < $station_level['price']){
        Ret::error('您的余额不足，请充值余额后再开通');
    }
    // 扣除用户余额
    $BalanceModel = new Balance_Model();
    $BalanceModel->dec(UID, $station_level['price'], '开通分站：' . $station_level['name']);
    // 创建分站
    $StationModel = new Station_Model();
    $StationModel->create(UID, $station_level['id'], $station_level['price']);
    // 开通分站流程结束
    Ret::success('分站开通成功');
}
