<?php



require_once '../init.php';

$action = Input::getStrVar('action');

if($action == 'getGoodsInfo'){
    $goods_id = Input::postIntVar('goods_id');
    $sku_ids = Input::postStrArray('sku_ids');
    $quantity = Input::postIntVar('quantity');
    $quantity = $quantity <= 0 ? 1 : $quantity;
    $quantity = (int)ceil($quantity);
    $goodsModel = new Goods_Model();
//    d($sku_ids);die;
    $goods = $goodsModel->getGoodsInfo([
        'goods_id' => $goods_id,
        'sku_ids' => $sku_ids,
        'quantity' => $quantity,
        'user_id' => UID,
        'user_level' => LEVEL,
    ]);
    Ret::success('', $goods);
}

if($action == 'xiadan'){
    
    $goods_id = Input::postIntVar('goods_id');
    $sku_ids = Input::postStrArray('sku_ids');
    $quantity = Input::postIntVar('quantity');
    $quantity = $quantity <= 0 ? 1 : $quantity;
    $quantity = (int)ceil($quantity);
    $payment_plugin = Input::postStrVar('payment_plugin');
    $payment_title = Input::postStrVar('payment_title');
    $attach = Input::postStrArray('attach');
    $required = Input::postStrArray('required');

    if(empty(UID) && $payment_plugin == 'balance'){
        Ret::error('未登录用户无法使用余额支付');
    }

    $orderModel = new Order_Model();
    $res = $orderModel->createOrder([
        'goods_id' => $goods_id,
        'sku_ids' => $sku_ids,
        'quantity' => $quantity,
        'payment_plugin' => $payment_plugin,
        'payment_title' => $payment_title,
        'attach' => $attach,
        'required' => $required,
        'user_id' => UID,
        'user_level' => LEVEL,
    ]);
    if(is_array($res)){
        Ret::success('success', $res);
    }
    
    if($res == 'sku-null'){
        Ret::error('请选择商品规格');
    }
    if($res == 'sku-incomplete'){
        Ret::error('请完整选择商品规格');
    }
    if($res == 'stock-insufficient'){
        Ret::error('库存不足');
    }
    if(strpos($res, 'attach-empty-') !== false){
        Ret::error('请填写' . str_replace('attach-empty-', '', $res));
    }
    if(strpos($res, 'required-empty-') !== false){
        Ret::error('请填写' . str_replace('required-empty-', '', $res));
    }
    if(strpos($res, 'error:') !== false){
        Ret::error(str_replace('error:', '', $res));
    }

    // var_dump($res);die;

    Ret::success('ok', [
        'out_trade_no' => $res,
    ]);

}