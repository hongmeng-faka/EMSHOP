<?php

defined('EM_ROOT') || exit('access denied!');
require_once View::getView('module');

$version = '1720327727';

$q = Input::getStrVar('q');

?>
<!doctype html>
<html lang="zh-cn" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?= $site_title ?></title>
    <meta name="keywords" content="<?= $site_key ?>"/>
    <meta name="description" content="<?= $site_description ?>"/>
    <link href="<?= empty(_g('favicon')) ? EM_URL . 'favicon.ico' : _g('favicon'); ?>" rel="icon">
    <link rel="alternate" title="RSS" href="<?= EM_URL ?>rss.php" type="application/rss+xml"/>


    <script src="../../../admin/views/js/jquery.min.3.5.1.js"></script>
    <!-- 字体 -->
    <link rel="stylesheet" type="text/css" href="../../../admin/views/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../../../admin/views/layui-v2.11.6/layui/css/layui.css">
    <script src="../../../admin/views/layui-v2.11.6/layui/layui.js"></script>
    



    <link rel="stylesheet" href="../../content/common/header.css?v=<?= Option::EM_VERSION_TIMESTAMP ?>">
    <script src="../../content/common/header.js?v=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>


    <link rel="stylesheet" href="../../content/static/css/em.css?v=<?= Option::EM_VERSION_TIMESTAMP ?>">
    <link href="<?= TEMPLATE_URL ?>css/style.css?v=<?= Option::EM_VERSION_TIMESTAMP ?>" rel="stylesheet"/>

    <script src="../../content/static/js/em.js?v=<?= Option::EM_VERSION_TIMESTAMP ?>"></script>


    <style>
        /* Flex Sticky Footer 实现 */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        /* 移动端适配 (992px以下 Header变更为Fixed定位，需要Padding占位) */
        @media (max-width: 768px) {
            body {
                /* padding-top: 56px; 移动端 Header 高度 */
            }
        }

        /* 主内容区域自动填充剩余空间 */
        main, .blog-container, .container {
            flex: 1 0 auto;
        }
        /* 页脚不伸缩 */
        footer, .main-footer {
            flex-shrink: 0;
        }
    </style>
    

    <?php doAction('index_head') ?>

    <?php if(Option::get('login_switch') == 'n' || Option::get('register_switch') == 'n'): ?>
    <style>
        .m-btn {
            right: 50px;
        }
    </style>
    <?php endif; ?>
</head>
<body>

<div id="mask"></div>
<header class="header">
    <div class="h-fix" id="h-fix">
        <div class="container">
            <?php if(empty(Option::get('logo'))): ?>
            <h1 class="logo-text">
                <a href="<?= EM_URL ?>" title="">
                    <span id="light-logo"><?= $blogname ?></span>
                </a>
            </h1>
            <?php else: ?>
            <h1 class="logo">
                <a href="<?= EM_URL ?>" title="">
                    <img id="light-logo" src="<?= Option::get('logo') ?>" alt="<?= $blogname ?>" title="<?= $blogname ?>">
                </a>
            </h1>
            <?php endif; ?>
            <div class="nav-container">
                <nav class="nav-bar" id="nav-box" data-type="index" data-infoid="">
                    <ul class="nav"><?php blog_navi() ?></ul>
                </nav>
            </div>
            <div class="header-right">
                
                <div class="header-right-btn">
                    <div class="header-search-order-btn">
                        <a href="<?= EM_URL ?>user/visitors.php" class="a transition">
                            <i class="fa fa-heart"></i>&nbsp;&nbsp;查询订单
                        </a>
                    </div>
                    <?php if(Option::get('login_switch') == 'y' && Option::get('register_switch') == 'y'): ?>
                    <div class="header-user">
                        <a href="<?= EM_URL ?>user/balance.php" class="">
                            <i class="fa fa-user"></i>
                        </a>
                    </div>
                    <?php endif; ?>
                    <div class="search" id="header-search"> 
                        <i class="s-btn off fa fa-search"></i>
                        <div class="s-form">
                            <i class="arrow fa fa-caret-up"></i>
                            <form name="formsearch" action="" class="sform">
                                <input class="sinput" name="q" type="text" placeholder="请输入搜索词" value="<?= $q ?>">
                                <button><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                    <div id="m-btn" class="m-btn"><i class="fa fa-bars"></i></div>
                </div>
            </div>
        </div>
    </div>
</header>
<div id="zhanwei"></div>
<script>
    // 获取header标签高度，设置占位高度，浏览器窗口变化的时候也要执行
    function setPlaceholderHeight() {
        var headerHeight = $('.h-fix').height();
        $('#zhanwei').css('height', headerHeight + 'px');
    }
    // 初始化时设置一次
    setPlaceholderHeight();
    // 浏览器窗口变化时也设置一次
    $(window).resize(setPlaceholderHeight);
</script>