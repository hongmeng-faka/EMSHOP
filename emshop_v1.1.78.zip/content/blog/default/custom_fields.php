<?php

/**
 * 模板预设的文章自定义字段
 */

defined('EM_ROOT') || exit('access denied!');

/*
$custom_fields = [
    'price' => [
        'type'        => 'text',
        'name'        => '价格',
        'description' => '如：9.99',
        'default'     => ''
    ],
    'need_vip' => [
        'type'        => 'radio',
        'name'        => '是否需要会员',
        'values'      => [
            '0' => '否',
            '1' => '是'
        ],
        'description' => '1是，0否',
        'default'     => '0'
    ],
];
*/
