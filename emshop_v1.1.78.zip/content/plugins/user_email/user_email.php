<?php
/*
Plugin Name: 发送卡密到用户邮箱
Version: 1.0.0
Plugin URL:
Description: 用户下单后，将卡密发送到用户邮箱里面 (发件邮箱信息请在系统管理处配置，用户邮箱从下单必填项处获取)
Author: 驳手
Author URL:
*/

defined('EM_ROOT') || exit('access denied!');






function user_email_plugin($data) {

//    d($data);die;

    if(empty($data['order']['email'])){
        return;
    }

    $smtp_port = Option::get('smtp_port');
    $smtp_server = Option::get('smtp_server');
    $smtp_mail = Option::get('smtp_mail');
    $smtp_pw = Option::get('smtp_pw');
    $smtp_from_name = Option::get('smtp_from_name');

    $mail = new PHPMailer(true);
    $mail->IsSMTP();
    $mail->CharSet = 'UTF-8';
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = $smtp_port == '587' ? 'STARTTLS' : 'ssl';
    $mail->Port = $smtp_port;
    $mail->Host = $smtp_server;
    $mail->Username = $smtp_mail;
    $mail->Password = $smtp_pw;
    $mail->From = $smtp_mail;
    $mail->FromName = $smtp_from_name;
    $mail->AddAddress($data['order']['email']);
    $mail->Subject = '请查看您的订单信息， 来自 - ' . Option::get('blogname');
    $mail->isHTML();

    $deliver_content = str_replace("\n", "<br>", $data['deliver_content']);

    $content = "尊敬的用户，非常感谢您选择我们的服务<br>
订单编号：{$data['out_trade_no']}<br>
商品名称：{$data['goods_name']}<br>
商品规格：{$data['sku']}<br>
购买数量：{$data['quantity']}<br>
订单金额：{$data['order_amount']}<br>
支付方式：{$data['payment']}<br>
支付时间：{$data['pay_time']}<br>
发货内容：<div style='background: #eee; padding: 10px; font-size: 16px;'>{$deliver_content}</div>
";

    $mail->Body = Notice::getMailTemplate($content);

    try {
        $mail->Send();
    } catch (Exception $exc) {

    }

}

addAction('deliver_after', 'user_email_plugin');


