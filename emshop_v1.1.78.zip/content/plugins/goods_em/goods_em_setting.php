<?php
defined('EM_ROOT') || exit('access denied!');

if(!function_exists('goodsEmPlugin')){
    emMsg('请先启用插件');
}


function plugin_setting_view() {
    
    ?>
    <style>
        body{
            overflow: hidden;
        }
        .layui-table-view-1 .layui-table-body .layui-table tr .layui-table-cell{
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 1; /* 限制显示2行 */
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .layui-table-tool-temp{
            padding-right: 0;
        }
    </style>
    <div style="padding: 20px 10px;" id="open-box">
        <table class="layui-hide" id="index" lay-filter="index"></table>
    </div>
    <script type="text/html" id="toolbar">
        <div class="layui-btn-container">
            <button class="layui-btn layui-btn-primary layui-border-green" lay-event="refresh">
                <i class="fa fa-refresh" style=""></i>
            </button>
            <button type="button" class="layui-btn" lay-event="add">添加</button>
            <button id="toolbar-del" class="layui-btn layui-btn-sm layui-bg-red layui-btn-disabled" lay-event="del">
                删除
            </button>
        </div>
    </script>


    <script type="text/html" id="operate">
        <div class="layui-clear-space">
            <a class="layui-btn layui-bg-blue" lay-event="add_goods">对接商品</a>
            <a class="layui-btn" lay-event="edit">编辑</a>
            <a class="layui-btn layui-bg-red" lay-event="del">删除</a>
        </div>
    </script>


    <script>
        layui.use(['table'], function(){
            var table = layui.table;
            var form = layui.form;
            // 创建渲染实例
            window.em_table = table.render({
                elem: '#index',
                autoSort: false,
                url: '/?plugin=goods_em&action=index', // 此处为静态模拟数据，实际使用时需换成真实接口
                toolbar: '#toolbar',
                limits: [10,20,30,50,100],
                page: false,
                lineStyle: 'height: 30px;',
                defaultToolbar: [],
                maxHeight : 'full-78',
                cols: [[
                    {type: 'checkbox'},
                    {field:'site_name', title:'店铺名称', align: 'center', minWidth: 100 },
                    {field:'url', title:'店铺地址', align: 'center', minWidth: 200 },
                    {field:'money', title:'余额', minWwidth: 150, align: 'center'},
                    {field:'expend', title:'总消费', minWwidth: 150, align: 'center'},
                    {title:'操作', templet: '#operate', width: 240, align: 'center'}
                ]],

                error: function(res, msg){
                    console.log(res, msg)
                }
            });

            // 工具栏事件
            table.on('toolbar(index)', function(obj){
                var id = obj.config.id;
                var checkStatus = table.checkStatus(id);
                var othis = lay(this);
                if(obj.event == 'refresh'){
                    table.reload(id);
                }
                if(obj.event == 'del'){
                    var data = checkStatus.data;
                    if(data.length == 0){
                        return false;
                    }
                    var ids = $.map(data, function(item) {
                        return item.id; // 提取每个对象的uid
                    }).join(',');
                    layer.confirm('确定要删除选中的数据？', {
                        btn: ['确认', '取消'], // 按钮
                        icon: 3,             // 图标，3表示问号
                        title: '温馨提示'
                    }, function(index) {
                        layer.close(index); // 关闭对话框
                        $.ajax({
                            url: '/?plugin=goods_em&action=del',
                            type: 'POST',
                            dataType: 'json',
                            data: { ids: ids, token: '<?= LoginAuth::genToken() ?>' },
                            success: function(res) {
                                layer.msg('删除成功');
                                table.reload(id);
                            },
                            error: function(err) {
                                layer.msg(err.responseJSON.msg);
                            }
                        });
                    });
                }
                if(obj.event == 'add'){
                    let isMobile = window.innerWidth < 768;
                    let area = isMobile ? ['98%', 'auto']  : ['700px', 'auto'];
                    layer.open({
                        id: 'add',
                        title: '添加对接站点',
                        type: 2,
                        area: area,
                        // skin: 'layui-layer-win10',
                        skin: 'layui-layer-molv',
                        content: '/?plugin=goods_em&action=add_site',
                        fixed: false, // 不固定
                        maxmin: true,
                        shadeClose: true,
                        success: function(layero, index, that){
                            layer.iframeAuto(index); // 让 iframe 高度自适应
                            that.offset(); // 重新自适应弹层坐标
                        }
                    });
                }

            });

            // 触发单元格工具事件
            table.on('tool(index)', function(obj){ // 双击 toolDouble
                var data = obj.data; // 获得当前行数据
                var id = obj.config.id;
                if(obj.event == 'del'){
                    layer.confirm('确定删除？', {
                        btn: ['确认', '取消'], // 按钮
                        icon: 3,             // 图标，3表示问号
                        title: '温馨提示'
                    }, function(index) {
                        layer.close(index); // 关闭对话框
                        $.ajax({
                            url: '/?plugin=goods_em&action=del',
                            type: 'POST',
                            dataType: 'json',
                            data: { ids: data.id, token: '<?= LoginAuth::genToken() ?>' },
                            success: function(res) {
                                layer.msg('删除成功');
                                table.reload(id);
                            },
                            error: function(err) {
                                layer.msg(err.responseJSON.msg);
                            }
                        });
                    });
                }
                if(obj.event == 'add_goods'){
                    let isMobile = window.innerWidth < 1200;
                    let area = isMobile ? ['98%', '85%']  : ['1000px', '800px'];
                    layer.open({
                        id: 'add_goods',
                        title: data.sitename,
                        type: 2,
                        area: area,
                        skin: 'layui-layer-molv',
                        content: '/?plugin=goods_em&action=add_goods&site_id=' + data.id,
                        fixed: false, // 不固定
                        maxmin: true,
                        shadeClose: true,
                        success: function(layero, index, that){
                            // layer.iframeAuto(index); // 让 iframe 高度自适应
                            // that.offset(); // 重新自适应弹层坐标
                        }
                    });
                }

                if(obj.event === 'edit'){
                    let isMobile = window.innerWidth < 768;
                    let area = isMobile ? ['98%', 'auto']  : ['700px', 'auto'];
                    layer.open({
                        id: 'edit',
                        title: '编辑库存',
                        type: 2,
                        area: area,
                        // skin: 'layui-layer-win10',
                        skin: 'layui-layer-molv',
                        content: '/?plugin=goods_em&action=edit_site&site_id=' + data.id,
                        fixed: false, // 不固定
                        maxmin: true,
                        shadeClose: true,
                        success: function(layero, index, that){
                            layer.iframeAuto(index); // 让 iframe 高度自适应
                            that.offset(); // 重新自适应弹层坐标
                        }
                    });
                }

            });

            

            // 触发表格复选框选择
            table.on('checkbox(index)', function(obj){
                var id = obj.config.id;
                var checkData = table.checkStatus(id).data;
                console.log(checkData)
                if(checkData.length == 0){
                    $('#toolbar-del').addClass('layui-btn-disabled');
                }else{
                    $('#toolbar-del').removeClass('layui-btn-disabled');
                }
            });
        });
    </script>
    <script>

        var maxHeight = $(window.parent).innerHeight() * 0.75;
        $("#open-box").css({
            "max-height": maxHeight + "px", // 单位必须加 px
            "overflow-y": "auto" // 内容超过 max-height 时显示垂直滚动条
        });
    </script>
<?php }

function plugin_setting() {

    $demo = Input::postStrVar('demo');

    $plugin_storage = Storage::getInstance('tips');
    $plugin_storage->setValue('demo', $demo);
    Output::ok();
}
