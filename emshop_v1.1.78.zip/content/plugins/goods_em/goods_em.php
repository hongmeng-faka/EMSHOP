<?php
/*
Plugin Name: 商品对接 【EMSHOP】
Version: 1.0.2
Plugin URL:
Description: 对接 EMSHOP 的商品
Author: 驳手
Author URL:
Ui: Layui
*/

defined('EM_ROOT') || exit('access denied!');

$db = Database::getInstance();
$db_prefix = DB_PREFIX;



/**
 * 初始化插件
 */
function goodsEmPlugin(){
    return true;
}

/**
 * 发货方法
 */
function pluginDeliver_em_auto($goods, $order, $child_order){
    $db = Database::getInstance();
    $db_prefix = DB_PREFIX;
    $em_goods = $db->once_fetch_array("select * from {$db_prefix}emshop_goods where local_goods_id = {$goods['id']}");
    $siteInfo = goodsEmGetSiteConfig($em_goods['site_id']);

    $timestamp = time();
    $sku = $child_order['sku'];
    $sku_ids = explode('-', $child_order['sku']);
    $data = [
        "user_id" => $siteInfo['user_id'], 
        "req_token" => $siteInfo['app_key'], 
        "req_time" => $timestamp,
        "goods_id" => $em_goods['em_goods_id'],
        "sku_ids" => $sku_ids,
        "quantity" => $child_order['quantity'],
        "attach" => json_decode($child_order['attach_user'], true),
        "required" => json_decode($siteInfo['order_required'], true)
    ];
    $data['req_sign'] = goodsEmGetReqSign($data);
    $url = $siteInfo['url'] . "?rest-api=submitOrder";
    $res = ebCurl($url, http_build_query($data), 1);
    
    if(empty($res)) return 'request fail';
    $res = json_decode($res, true);
    if($res['code'] == 400){
        Log::error('发货失败: ' . $res['msg'] . '. 订单号: ' . $order['out_trade_no']);
        die(json_encode($res, JSON_UNESCAPED_UNICODE));
    }
    $data = $res['data'];
    // 更新商品规格表的库存和销量
    if($data['status'] == -1){
        $idsCount = count($data['content']);
    }
    if($data['status'] == 1){
        $idsCount = 0;
    }
    if($data['status'] == 2){
        $idsCount = count($data['content']);
    }
    if($idsCount > 0){
        $insert = [
            'goods_id' => $child_order['goods_id'],
            'order_list_id' => $child_order['id'],
            'sku' => $child_order['sku'],
            'create_time' => $timestamp,
        ];
        foreach($data['content'] as $val){
            $insert['content'] = $val;
            $db->add('emshop_sales', $insert);
        }
    }
    $db->query("update {$db_prefix}skus set sales = sales + {$idsCount}, stock = stock - {$idsCount} where goods_id = {$child_order['goods_id']} and sku = '{$sku}'");
    // 更新订单状态
    $db->query("UPDATE {$db_prefix}order SET status = {$data['status']}, pay_time = {$timestamp} WHERE id = '{$order['id']}'"); // 全部发货
    return [
        'status' => $data['status'],
        'content' => $data['content']
    ];
}
function pluginDeliver_em_manual($goods, $order, $child_order){
    $db = Database::getInstance();
    $db_prefix = DB_PREFIX;
    $em_goods = $db->once_fetch_array("select * from {$db_prefix}emshop_goods where local_goods_id = {$goods['id']}");
    $siteInfo = goodsEmGetSiteConfig($em_goods['site_id']);

    $timestamp = time();
    $sku = $child_order['sku'];
    $sku_ids = explode('-', $child_order['sku']);
    $data = [
        "user_id" => $siteInfo['user_id'], 
        "req_token" => $siteInfo['app_key'], 
        "req_time" => $timestamp,
        "goods_id" => $em_goods['em_goods_id'],
        "sku_ids" => $sku_ids,
        "quantity" => $child_order['quantity'],
        "attach" => json_decode($child_order['attach_user'], true),
        "required" => json_decode($siteInfo['order_required'], true)
    ];
    $data['req_sign'] = goodsEmGetReqSign($data);
    $url = $siteInfo['url'] . "?rest-api=submitOrder";
    $res = ebCurl($url, http_build_query($data), 1);

    
    if(empty($res)) return 'request fail';
    $res = json_decode($res, true);
    if($res['code'] == 400){
        Log::error('发货失败: ' . $res['msg'] . '. 订单号: ' . $order['out_trade_no']);
        die(json_encode($res, JSON_UNESCAPED_UNICODE));
    }
    $data = $res['data'];
    // 更新商品规格表的库存和销量
    if($data['status'] == -1){
        $idsCount = count($data['content']);
    }
    if($data['status'] == 1){
        $idsCount = 0;
    }
    if($data['status'] == 2){
        $idsCount = count($data['content']);
    }
    $insert = [
        'goods_id' => $child_order['goods_id'],
        'order_list_id' => $child_order['id'],
        'sku' => $child_order['sku'],
        'create_time' => $timestamp,
    ];
    foreach($data['content'] as $val){
        $insert['content'] = $val;
        $db->add('emshop_sales', $insert);
    }
    $db->query("update {$db_prefix}skus set sales = sales + {$idsCount}, stock = stock - {$idsCount} where goods_id = {$child_order['goods_id']} and sku = '{$sku}'");
    // 更新订单状态
    // d($data);die;
    $remote_trade = empty($data['out_trade_no']) ? '' : $data['out_trade_no'];
    // var_dump($remote_trade);die;
    $db->query("UPDATE {$db_prefix}order SET status = {$data['status']}, remote_trade = '{$remote_trade}', pay_time = {$timestamp} WHERE id = '{$order['id']}'"); // 全部发货
    return [
        'status' => $data['status'],
        'content' => $data['content']
    ];
}



// 订单列表按钮
function plugin_goods_em_user_order_list_btn($order, $child_order){
    if($child_order['type'] == 'em_auto' || $child_order['type'] == 'em_manual'){
        if(!empty($order['pay_time'])){
            echo <<<html
    <a href="?action=sdk&out_trade_no={$order['out_trade_no']}" class="layui-btn">
        查看卡密信息
    </a>
    <a href="{$child_order['url']}" target="_blank" class="layui-btn layui-bg-cyan">再次购买</a>
html;
        }
    }
}
addAction('user_order_list_btn', 'plugin_goods_em_user_order_list_btn');

// 显示订单详情页
function plugin_goods_em_view_order_detail($db, $db_prefix, $goods, $order, $child_order){
    if($goods['type'] == 'em_auto' || $goods['type'] == 'em_manual'){
        $cmd = Input::getStrVar('cmd');
        $kami = $db->fetch_all("select * from {$db_prefix}emshop_sales where order_list_id = {$child_order['id']} order by id asc");
        if($cmd == 'download'){
            $content = "";
            foreach($kami as $val){
                $content .= $val['content'] . "\r\n";
            }
            $date = date('YmdHis');
            $filename = '卡密-' . $date . '.txt';
            // 设置HTTP头
            header('Content-Type: text/plain');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . strlen($content));
            // 输出内容
            echo $content;
            exit;
        }
        $kami = $db->fetch_all("select * from {$db_prefix}emshop_sales where order_list_id = {$child_order['id']} limit 500");
        $res = $db->once_fetch_array("select count(id) total from {$db_prefix}emshop_sales where order_list_id = {$child_order['id']}");
        $total = empty($res) ? 0 : $res['total'];
        include View::getUserView('_header');
        include EM_ROOT . "/content/plugins/goods_em/views/order_detail.php";
        include View::getUserView('_footer');
        View::output();
    }
}
addAction('view_order_detail', 'plugin_goods_em_view_order_detail');

function plugin_goods_em_auto_get_order_serect($db, $db_prefix, $goods, $order, $child_order, $limit){
    $sql = "select * from {$db_prefix}emshop_sales where order_list_id = {$child_order['id']} order by id asc";
    if(!empty($limit)){
        $sql .= " limit {$limit}";
    }
    $kami = $db->fetch_all($sql);
    $sql = "select count(id) res_count from {$db_prefix}emshop_sales where order_list_id = {$child_order['id']}";
    $res = $db->once_fetch_array($sql);
    return [
        'count' => $res['res_count'],
        'list' => $kami
    ];
}
function plugin_goods_em_manual_get_order_serect($db, $db_prefix, $goods, $order, $child_order, $limit){
    $sql = "select * from {$db_prefix}emshop_sales where order_list_id = {$child_order['id']} order by id asc";
    if(!empty($limit)){
        $sql .= " limit {$limit}";
    }
    $kami = $db->fetch_all($sql);
    $sql = "select count(id) res_count from {$db_prefix}emshop_sales where order_list_id = {$child_order['id']}";
    $res = $db->once_fetch_array($sql);
    return [
        'count' => $res['res_count'],
        'list' => $kami
    ];
}

/**
 * 保存商品
 */
function goodsEmSaveGoods($siteInfo, $goods_ids, $rasie, $num){
    $timestamp = time();
    $reqData = ["user_id" => $siteInfo['user_id'], "req_token" => $siteInfo['app_key'], "req_time" => $timestamp];
    $goods_ids = explode(',', $goods_ids);
    $goodsModel = new Goods_Model();
    global $db, $db_prefix;
    foreach($goods_ids as $key => $val){
        $reqData['goods_id'] = $val;
        $reqData['req_sign'] = goodsEmGetReqSign($reqData);
        $url = $siteInfo['url'] . "?rest-api=getGoodsInfo";
        $res = ebCurl($url, http_build_query($reqData), 1);
        // echo $res;
        $res = json_decode($res, true);
        $data = $res['data'];
        // d($data);die; 
        $skus = $data['skus'];
        if($rasie == 1){ // 按金额加价
            foreach($skus as $k => $v){
                $skus[$k]['cost_price'] = $v['price'];
                // 使用整数运算避免精度问题：将元转为分进行计算，最后再转回元
                $price_fen = round($v['price'] * 100);
                $num_fen = round($num * 100);
                $skus[$k]['guest_price'] = round(($price_fen + $num_fen) / 100, 2);
                $skus[$k]['user_price'] = round(($price_fen + $num_fen) / 100, 2);
                $skus[$k]['sales'] = 0;
            }
        }else{ // 按比例加价
            foreach($skus as $k => $v){
                $skus[$k]['cost_price'] = $v['price'];
                // 使用整数运算避免精度问题：将元转为分进行计算，最后再转回元
                $price_fen = round($v['price'] * 100);
                // 比例计算：price * (1 + num/100) = price * (100 + num) / 100
                $new_price_fen = intval($price_fen * (100 + ($num * 100)) / 100);
                $skus[$k]['guest_price'] = round($new_price_fen / 100, 2);
                $skus[$k]['user_price'] = round($new_price_fen / 100, 2);
                $skus[$k]['sales'] = 0;
            }
        }
        if($data['is_sku'] == 'n'){
            $skus = $skus[0];
        }
        // if(!isset($data['is_auto'])) Ret::error('该商品发货类型错误：' . $data['title']);
        $local_goods_insert = [
            'type' => $data['is_auto'] == true ? 'em_auto' : 'em_manual',
            'sort_id' => -1,
            'is_on_shelf' => 1,
            'title' => $data['title'],
            'cover' => $siteInfo['url'] . ltrim($data['cover'], '../'),
            'is_sku' => $data['is_sku'],
            'attr_id' => -1,
            'skus' => $skus,
            'des' => $data['des'],
            'content' => $data['content'],
            'pay_content' => $data['pay_content'],
            'attach_user' => json_decode($data['attach_user'], true),
            'index_top' => 0,
            'sort_top' => 0,
            'sort_num' => 0
        ];
        // d($local_goods_insert);
        $goods_id = $goodsModel->addGoods($local_goods_insert);
        // var_dump($goods_id); die;
        $origin_goods_insert = [
            'site_id' => $siteInfo['id'],
            'local_goods_id' => $goods_id,
            'em_goods_id' => $data['id'],
        ];
        $db->add('emshop_goods', $origin_goods_insert);
    }
    return 'success';
}

/**
 * 获取站点配置
 */
function goodsEmGetSiteConfig($site_id){
    global $db, $db_prefix;
    $siteinfo = $db->once_fetch_array("select * from {$db_prefix}emshop_site where id = {$site_id}");
    return $siteinfo;
}

/**
 * 获取商品分类
 */
function goodsEmGetGoodsSort($siteInfo){
    $timestamp = time();
    $data = ["user_id" => $siteInfo['user_id'], "req_token" => $siteInfo['app_key'], "req_time" => $timestamp];
    $data['req_sign'] = goodsEmGetReqSign($data);
    $url = $siteInfo['url'] . "?rest-api=getGoodsSort";
    $res = ebCurl($url, http_build_query($data), 1);
    if(empty($res)) return 'request fail';
    $res = json_decode($res, true);
    // d($res);die;
    return $res['data'];
}

/**
 * 获取商品列表
 */
function goodsEmGetGoodsList($siteInfo){
    $timestamp = time();
    $data = ["user_id" => $siteInfo['user_id'], "req_token" => $siteInfo['app_key'], "req_time" => $timestamp];
    $data['req_sign'] = goodsEmGetReqSign($data);
    $url = $siteInfo['url'] . "?rest-api=getGoodsList";
    $res = ebCurl($url, http_build_query($data), 1);
    // echo $res;die;
    if(empty($res)) return 'request fail';
    $res = json_decode($res, true);
    return $res;
}

/**
 * 获取对接站列表
 */
function goodsEmGetSiteList(){
    global $db, $db_prefix;
    $list = $db->fetch_all("select * from {$db_prefix}emshop_site order by id asc");

    $timestamp = time();

    foreach($list as $key => $val){
        $data = ["user_id" => $val['user_id'], "req_token" => $val['app_key'], "req_time" => $timestamp];
        $data['req_sign'] = goodsEmGetReqSign($data);
        $url = $val['url'] . "?rest-api=getUserInfo";
        $res = ebCurl($url, http_build_query($data), 1);
        $res = json_decode($res, true);
        if($res['code'] == 200){
            if($val['money'] != $res['data']['money'] || $val['expend'] != $res['data']['expend']){
                $db->update("emshop_site", [
                    "money" => $res['data']['money'], 
                    "expend" => $res['data']['expend'],
                    "update_time" => $timestamp
                ], ["id" => $val['id']]);
                $list[$key]['money'] = $res['data']['money'];
                $list[$key]['expend'] = $res['data']['expend'];
            }
        }
        
    }
    return $list;
}

/**
 * 生成签名
 */
function goodsEmGetReqSign($data){
    ksort($data);
    foreach ($data as $key => $val) {
        if ($val === '') {
            unset($data[$key]);
        }
    }
    return md5($data['req_time'] . $data['req_token']);
}

/**
 * 获取商品规格模板详情
 * 通过post.goods_id查询emshop_goods表，获取到所属的对接站点
 * 然后获取emshop_site的站点信息，通过站点信息表去请求源站的接口
 */
function plugin_goods_em_adm_edit_goods_attr_spec_data($post){
    if(in_array($post['goods_type'], ['em_auto', 'em_manual'])){
        global $db, $db_prefix;
        $goods_id = $post['goods_id'];
        $em_goods = $db->once_fetch_array("select * from {$db_prefix}emshop_goods where local_goods_id = {$goods_id}");
        $siteInfo = $db->once_fetch_array("select * from {$db_prefix}emshop_site where id = {$em_goods['site_id']}");
        $data = [
            "goods_id" => $em_goods['em_goods_id'],
            "goods_type_id" => $post['goods_type_id'],
            "user_id" => $siteInfo['user_id'], 
            "req_token" => $siteInfo['app_key'], 
            "req_time" => time()
        ];
        $data['req_sign'] = goodsEmGetReqSign($data);
        $url = $siteInfo['url'] . "?rest-api=getSkuTemplateInfo";
        $res = ebCurl($url, http_build_query($data), 1);
        $res = json_decode($res, true);
        die(json_encode(['code' => 200, 'data' => $res['data'], 'msg' => 'ok']));
    }
}
addAction('adm_edit_goods_attr_spec_data', 'plugin_goods_em_adm_edit_goods_attr_spec_data');

/**
 * 获取商品规格模板
 * 通过post.goods_id查询emshop_goods表，获取到所属的对接站点
 * 然后获取emshop_site的站点信息，通过站点信息表去请求源站的接口
 */
function plugin_goods_em_adm_edit_goods_goods_type_data($post){
    if(in_array($post['goods_type'], ['em_auto', 'em_manual'])){
        global $db, $db_prefix;
        $goods_id = $post['goods_id'];
        $em_goods = $db->once_fetch_array("select * from {$db_prefix}emshop_goods where local_goods_id = {$goods_id}");
        $siteInfo = $db->once_fetch_array("select * from {$db_prefix}emshop_site where id = {$em_goods['site_id']}");
        $data = ["user_id" => $siteInfo['user_id'], "req_token" => $siteInfo['app_key'], "req_time" => time()];
        $data['req_sign'] = goodsEmGetReqSign($data);
        $url = $siteInfo['url'] . "?rest-api=getSkuTemplate";
        $res = ebCurl($url, http_build_query($data), 1);
        $res = json_decode($res, true);
        die(json_encode(['code' => 200, 'data' => $res['data'], 'msg' => 'ok']));
    }
}
addAction('adm_edit_goods_goods_type_data', 'plugin_goods_em_adm_edit_goods_goods_type_data');

/**
 * 展示后台商品列表的商品类型徽章
 */
function plugin_goods_list_type_em($type){
    echo <<<html
{{#  if(d.type == 'em_auto' || d.type == 'em_manual'){ }}
<span class="layui-badge layui-bg-cyan">EMSHOP</span>
{{#  } }}
html;
}
addAction('adm_goods_list_type', 'plugin_goods_list_type_em');

/**
 * 商品编辑页隐藏元素
 */
function plugin_goods_em_goods_edit_page(){
    global $goods;
    if($goods['type'] == 'em_auto' || $goods['type'] == 'em_manual'){
        echo <<<html
<script>
$(function(){
    $('#s1').hide();
    $('#user_attach_box').hide();
    $('#keyValueList .delete-btn').hide();
    $('#form').append(`<input type="hidden" name="attr_id" value="-1" />`);
})
</script>
html;
    }
}
addAction('goods_eidt_form_foot', 'plugin_goods_em_goods_edit_page');

/**
 * 获取商品详情
 */
function plugin_goods_em_goods_model_get_goods_info($goods, &$result){
    if($goods['type'] == 'em_auto' || $goods['type'] == 'em_manual'){
        global $db, $db_prefix;
        $em_goods = $db->once_fetch_array("select * from {$db_prefix}emshop_goods where local_goods_id = {$goods['id']}");
        $siteInfo = $db->once_fetch_array("select * from {$db_prefix}emshop_site where id = {$em_goods['site_id']}");
        $timestamp = time();
        $data = ["user_id" => $siteInfo['user_id'], "req_token" => $siteInfo['app_key'], "req_time" => $timestamp];
        $data['goods_id'] = $em_goods['em_goods_id'];
        $data['sku_ids'] = $goods['selected_sku'];
        $data['quantity'] = $goods['quantity'];
        $data['req_sign'] = goodsEmGetReqSign($data);
        // d($data);die;
        $url = $siteInfo['url'] . "?rest-api=getGoodsInfo";
        $res = ebCurl($url, http_build_query($data), 1);
        // echo $res;die;
        $res = json_decode($res, true);
        $data = $res['data'];
        // d($data); die; 
        $result = $data;
        return $result;
    }
}
addAction('goods_model_get_goods_info', 'plugin_goods_em_goods_model_get_goods_info');



// 后台发货页面
function plugin_goods_em_adm_deliver_view($db, $db_prefix, $goods, $order, $child_order){
    if($goods['type'] == 'em_auto' || $goods['type'] == 'em_manual'){
        include View::getAdmView('open_head');
        require_once EM_ROOT . "/content/plugins/goods_em/views/adm_deliver_view.php";
        include View::getAdmView('open_foot');
        View::output();
    }
}
addAction('adm_deliver_view', 'plugin_goods_em_adm_deliver_view');


// 未售库存页面
function plugin_goods_em_stock_ws($goods, &$result){
    if($goods['type'] == 'em_auto' || $goods['type'] == 'em_manual'){
        $goods['stock_page'] = "../../content/plugins/goods_em/views/stock";
        $result = $goods;
    }
}
addAction('adm_stock_page_ws', 'plugin_goods_em_stock_ws');
