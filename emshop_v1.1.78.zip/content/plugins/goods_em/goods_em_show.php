<?php
defined('EM_ROOT') || exit('access denied!');
$action = Input::getStrVar('action');
$db = Database::getInstance();
$db_prefix = DB_PREFIX;
$timestamp = time();



if(User::isAdmin()){
    // 对接站点列表
    if($action == 'index'){
        $list = goodsEmGetSiteList();
        output::data($list, count($list));
    }
    // 删除对接站点
    if($action == 'del'){
        $ids = Input::postStrVar('ids');
        if(empty($ids)) output::error('请选择要删除的对接站点');
        $db->del('emshop_site', $ids);
        Ret::success('删除成功');
    }
    // 添加对接站点
    if($action == 'add_site'){
        include View::getAdmView('open_head');
        require_once(EM_ROOT . '/content/plugins/goods_em/views/add_site.php');
        include View::getAdmView('open_foot');
        View::output();
    }
    // 保存添加信息
    if($action == 'add_site_save'){
        $domain = Input::postStrVar('domain');
        $user_id = Input::postStrVar('user_id');
        $token = Input::postStrVar('api_token');
        if(empty($domain)) output::error('请输入店铺地址');
        if(empty($user_id)) output::error('请输入商户ID');
        if(empty($token)) output::error('请输入商户密钥');
        $domain = trim($domain, '/');
        $domain .= '/';

        $data = ["user_id" => $user_id, "req_token" => $token, "req_time" => $timestamp];
        $data['req_sign'] = goodsEmGetReqSign($data);

        $url = $domain . "?rest-api=getEmInfo";
        $res = ebCurl($url, http_build_query($data), 1);
        if(empty($res)) Ret::error('店铺连接失败，网络问题或信息有误。');
        $res = json_decode($res, true);
        // d($res);die;
        if($res['code'] == 400) Ret::error($res['msg']);
        $site_name = $res['data']['site_name'];
        $url = $domain . "?rest-api=getUserInfo";
        $res = ebCurl($url, http_build_query($data), 1);
        $res = json_decode($res, true);
        // d($res);die;
        if($res['code'] == 400) Ret::error($res['msg']);
        $money = $res['data']['money'];
        $expend = $res['data']['expend'];
        $insert = [
            'site_name' => $site_name,
            'money' => $money,
            'expend' => $expend,
            'url' => $domain,
            'user_id' => $user_id,
            'app_key' => $token,
            'create_time' => $timestamp
        ];
        $db->add('emshop_site', $insert);
        Ret::success('success');
    }
    // 编辑对接站点
    if($action == 'edit_site'){
        $site_id = Input::getIntVar('site_id');
        $info = goodsEmGetSiteConfig($site_id);
        include View::getAdmView('open_head');
        require_once(EM_ROOT . '/content/plugins/goods_em/views/edit_site.php');
        include View::getAdmView('open_foot');
        View::output();
    }
    // 保存编辑信息
    if($action == 'edit_site_save'){
        $site_id = Input::postIntVar('site_id');
        $domain = Input::postStrVar('domain');
        $user_id = Input::postStrVar('user_id');
        $token = Input::postStrVar('api_token');
        if(empty($domain)) Ret::error('请输入店铺地址');
        if(empty($user_id)) Ret::error('请输入商户ID');
        if(empty($token)) Ret::error('请输入商户密钥');
        $domain = trim($domain, '/');
        $domain .= '/';

        $data = ["user_id" => $user_id, "req_token" => $token, "req_time" => $timestamp];
        $data['req_sign'] = goodsEmGetReqSign($data);

        $url = $domain . "?rest-api=getEmInfo";
        $res = ebCurl($url, http_build_query($data), 1);
        if(empty($res)) Ret::error('店铺连接失败，网络问题或信息有误。');
        $res = json_decode($res, true);
        // d($res);die;
        if($res['code'] == 400) Ret::error($res['msg']);
        $site_name = $res['data']['site_name'];
        $order_required = $res['data']['order_required'];
        $url = $domain . "?rest-api=getUserInfo";
        $res = ebCurl($url, http_build_query($data), 1);
        $res = json_decode($res, true);
        // d($res);die;
        if($res['code'] == 400) Ret::error($res['msg']);
        $money = $res['data']['money'];
        $expend = $res['data']['expend'];
        $update = [
            'site_name' => $site_name,
            'money' => $money,
            'expend' => $expend,
            'url' => $domain,
            'user_id' => $user_id,
            'app_key' => $token,
            'create_time' => $timestamp
        ];
        $db->update('emshop_site', $update, ['id' => $site_id]);
        Ret::success('success', [
            'order_required' => $order_required,
        ]);
    }

    if($action == 'save_order_required'){
        $site_id = Input::postIntVar('site_id');
        $order_required = Input::postStrArray('required');
        $order_required = json_encode($order_required, JSON_UNESCAPED_UNICODE);
        $update = [
            'order_required' => $order_required,
        ];
        // d($update);die;
        $db->update('emshop_site', $update, ['id' => $site_id]);
        Ret::success('success');
    }

    // 添加商品页面
    if($action == 'add_goods'){
        $site_id = Input::getIntVar('site_id');
        $sort_id = Input::getIntVar('sort_id');
        $siteInfo = goodsEmGetSiteConfig($site_id);

        $data = ["user_id" => $siteInfo['user_id'], "req_token" => $siteInfo['app_key'], "req_time" => $timestamp];
        $data['req_sign'] = goodsEmGetReqSign($data);
        // d($data);die;
        $url = $siteInfo['url'] . "?rest-api=getEmInfo";
        // echo $url;die;
        $res = ebCurl($url, http_build_query($data), 1);
        // echo $res;die;
        if(empty($res)) Ret::error('店铺连接失败，网络问题或信息有误。');
        $res = json_decode($res, true);
        $emInfo = $res['data'];
        // d($siteInfo);die;
        
        $is_need_setting_reqired = false;
        if(!empty($emInfo['order_required'])){
            $setting_required = empty($siteInfo['order_required']) ? [] : json_decode($siteInfo['order_required'], true);
            // d($setting_required);die;
            if(empty($setting_required)) {
                $is_need_setting_reqired = true;
            }else{
                foreach($emInfo['order_required'] as $val){
                    $is_exists = false;
                    $is_empty = false;
                    foreach($setting_required as $k => $v){
                        if($val['name'] == $k){
                            $is_exists = true;
                            if(empty($v)) $is_empty = true;
                        }
                    }
                    if(!$is_exists){
                        $is_need_setting_reqired = true;
                        break;
                    }
                    if($is_empty){
                        $is_need_setting_reqired = true;
                        break;
                    }
                }
            }
            
        }

        $sort = goodsEmGetGoodsSort($siteInfo);
        $sort_id = empty($sort_id) ? $sort[0]['sort_id'] : $sort_id;
        $res = goodsEmGetGoodsList($siteInfo);
        $err_code = 0;
        if($res == 'request fail') $err_code = 1;
        if($res['code'] == 400) $err_code = $res['msg'];
        $goods = $res['data'];
        include View::getAdmView('open_head');
        require_once(EM_ROOT . '/content/plugins/goods_em/views/add_goods.php');
        include View::getAdmView('open_foot');
        View::output();
    }

    // 保存商品
    if($action == 'save_goods'){
        $site_id = Input::postIntVar('site_id');
        $goods_ids = Input::postStrVar('goods_ids');
        $rasie = Input::postIntVar('rasie');
        $num = Input::postStrVar('num');
        if(empty($goods_ids)) Ret::error('请选择商品');
        if(empty($rasie)) Ret::error('请选择加价模式');
        if(empty($num)) Ret::error('请输入加价数值');

        
        $siteInfo = goodsEmGetSiteConfig($site_id);

        $res = goodsEmSaveGoods($siteInfo, $goods_ids, $rasie, $num);
        if($res == 'success') Ret::success();
    }






}

