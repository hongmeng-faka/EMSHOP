<?php defined('EM_ROOT') || exit('access denied!'); ?>

<?php if($is_need_setting_reqired): ?>
<!-- 设置对接站点的下单必填项 -->
<form class="layui-form " action="/?plugin=goods_em&action=save_order_required" id="form">
    <div style="padding: 25px;" id="open-box">
        <!-- 提示信息 -->
        <div class="layui-alert layui-alert-warning" style="margin-bottom: 20px; padding: 15px; background-color: #fff7e6; border: 1px solid #ffd591; border-radius: 4px; color: #d46b08;">
            <i class="layui-icon layui-icon-about" style="margin-right: 8px;"></i>
            <strong>请先设置对接站点的下单必填项</strong><br>
            <small style="color: #8c6d3d;">完成必填项设置后，才能进行商品添加操作。请根据对接站点的要求填写相应的信息。</small>
        </div>
        <?php foreach($emInfo['order_required'] as $val): ?>
        <div class="layui-form-item">
            <label class="layui-form-label"><?= $val['name'] ?></label>
            <div class="layui-input-block">
                <input type="text" class="layui-input" value="<?= $setting_required[$val['name']] ?? '' ?>" name="required[<?= $val['name'] ?>]" placeholder="<?= $val['placeholder'] ?>" />
            </div>
        </div>
        <?php endforeach; ?>
        <input name="site_id" value="<?= $site_id ?>" type="hidden"/>
        <input name="token" id="token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
    </div>
    <div style="width: 100%; height: 50px;"></div>
    <div class="" id="form-btn">
        <div class="layui-input-block" style="margin: 0 auto;">
            <button type="submit" class="layui-btn" lay-submit lay-filter="submit">保存商品</button>
            <button type="reset" class="layui-btn layui-btn-primary">重置</button>
        </div>
    </div>
</form>
<script>
    layui.use(function(){
        var $ = layui.$;
        var form = layui.form;

        form.on('submit(submit)', function(data){
            var field = data.field; // 获取表单全部字段值
            var url = $('#form').attr('action');
            $.ajax({
                type: "POST",
                url: url,
                data: field,
                dataType: "json",
                success: function (e) {
                    if(e.code != 200){
                        layer.msg(e.msg);
                        return false;
                    }
                    layer.msg(e.msg);
                    window.location.reload();
                },
                error: function (xhr) {
                    layer.msg(JSON.parse(xhr.responseText).msg);
                },
                complete: function() {
                }
            });


            return false; // 阻止默认 form 跳转
        });
    })

</script>
<?php else: ?>
<?php if(!empty($err_code)): ?>
<style>
    .error-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: calc(100vh - 100px);
        font-family: Arial, sans-serif;
        text-align: center;
        padding: 20px;
    }
    .error-icon {
        font-size: 64px;
        color: #ff6b6b;
        margin-bottom: 20px;
    }
    .error-title {
        font-size: 24px;
        color: #333;
        margin-bottom: 10px;
    }
    .error-message {
        font-size: 16px;
        color: #666;
        margin-bottom: 30px;
        max-width: 400px;
    }
    .retry-btn {
        background-color: #1E9FFF;
        color: white;
        border: none;
        padding: 12px 30px;
        font-size: 16px;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .retry-btn:hover {
        background-color: #0078d7;
    }
</style>

<div class="error-container">
    <div class="error-icon">⚠️</div>
    <div class="error-title">
        <?php if($err_code == 1): ?>
            对接站点请求失败
        <?php else: ?>
            <?= htmlspecialchars($err_code) ?>
        <?php endif; ?>
    </div>
    <button class="retry-btn" onclick="location.reload()">重试</button>
</div>

<?php else: ?>
<style>

    /* 分类卡片样式 */
    .sort-cards-container {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 5px;
    }
    
    .sort-card {
        background-color: #f8f9fa;
        border: 2px solid #e9ecef;
        border-radius: 6px;
        padding: 8px 16px;
        cursor: pointer;
        transition: all 0.3s ease;
        user-select: none;
        min-width: 80px;
        text-align: center;
    }
    
    .sort-card:hover {
        border-color: #1E9FFF;
        background-color: #f0f8ff;
        transform: translateY(-1px);
        box-shadow: 0 2px 8px rgba(30, 159, 255, 0.15);
    }
    
    .sort-card.active {
        border-color: #1E9FFF;
        background-color: #1E9FFF;
        color: white;
        box-shadow: 0 2px 8px rgba(30, 159, 255, 0.3);
    }
    
    .sort-card .sort-name {
        font-size: 14px;
        font-weight: 500;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    /* 商品卡片样式 */
    .goods-cards-container {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 10px;
        margin-top: 5px;
        max-height: 300px;
        overflow-y: auto;
        padding: 5px;
    }
    
    .goods-card {
        background-color: #ffffff;
        border: 2px solid #e9ecef;
        border-radius: 6px;
        padding: 12px;
        cursor: pointer;
        transition: all 0.3s ease;
        user-select: none;
        display: flex;
        align-items: center;
        position: relative;
    }
    .goods-card .layui-form-checkbox{
        display: none;
    }
    
    .goods-card:hover {
        border-color: #1E9FFF;
        box-shadow: 0 2px 8px rgba(30, 159, 255, 0.15);
        transform: translateY(-1px);
    }
    
    .goods-card.selected {
        border-color: #1E9FFF;
        background-color: #f0f8ff;
        box-shadow: 0 2px 8px rgba(30, 159, 255, 0.3);
    }
    
    .goods-card.hidden {
        display: none;
    }
    
    .goods-checkbox {
        display: none !important;
    }
    
    .goods-card input[type="checkbox"] {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        width: 0 !important;
        height: 0 !important;
        position: absolute !important;
        left: -9999px !important;
    }
    
    .goods-info {
        flex: 1;
        min-width: 0;
    }
    
    .goods-title {
        font-size: 14px;
        font-weight: 500;
        color: #333;
        line-height: 1.4;
        display: block;
        word-break: break-all;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }
</style>


<form class="layui-form " action="/?plugin=goods_em&action=save_goods" id="form">
    <div style="padding: 25px;" id="open-box">
        <div class="layui-form-item">
            <label class="layui-form-label">选择分类</label>
            <div class="layui-input-block">
                <input type="hidden" name="sort_id" id="sort_id" value="<?= isset($sort_id) ? $sort_id : '' ?>" />
                <div class="sort-cards-container">
                    <?php if(isset($sort) && is_array($sort)): ?>
                        <?php foreach($sort as $val): ?>
                        <div class="sort-card <?= (isset($sort_id) && $sort_id == $val['sort_id']) ? 'active' : '' ?>" 
                             data-sort-id="<?= $val['sort_id'] ?>">
                            <span class="sort-name"><?= $val['sortname'] ?> (<?= $val['goods_count'] ?>)</span>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">选择商品</label>
            <div class="layui-input-block">
                <input type="hidden" name="goods_ids" id="goods_ids" value="" />
                <div class="goods-cards-container">
                    <?php if(isset($goods) && is_array($goods)): ?>
                        <?php foreach($goods as $val): ?>
                        <div class="goods-card" data-goods-id="<?= $val['goods_id'] ?>" data-sort-id="<?= $val['sort_id'] ?>">
                            <input type="checkbox" id="goods_<?= $val['goods_id'] ?>" value="<?= $val['goods_id'] ?>">
                            <div class="goods-info">
                                <span class="goods-title"><?= htmlspecialchars($val['title']) ?></span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">加价模式</label>
            <div class="layui-input-block">
                <input type="radio" name="rasie" value="1"  title="按金额增加">
                <input type="radio" name="rasie" value="2"  title="按比例增加">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">加价数值</label>
            <div class="layui-input-block">
                <input type="number" class="layui-input" name="num" />
                <span class="form-tips">按金额增加，直接填写要增加的金额即可。按比例增加，填写0.5则代表价格增加50%</span>
            </div>
        </div>



        <input name="site_id" value="<?= $site_id ?>" type="hidden"/>
        <input name="token" id="token" value="<?= LoginAuth::genToken() ?>" type="hidden"/>
    </div>
    <div style="width: 100%; height: 50px;"></div>
    <div class="" id="form-btn">
        <div class="layui-input-block" style="margin: 0 auto;">
            <button type="submit" class="layui-btn" lay-submit lay-filter="submit">保存商品</button>
            <button type="reset" class="layui-btn layui-btn-primary">重置</button>
        </div>
    </div>
</form>


<script>
    layui.use(function(){
        var $ = layui.$;
        var form = layui.form;

        // 分类卡片点击事件
        $('.sort-cards-container').on('click', '.sort-card', function(){
            var $this = $(this);
            var sortId = $this.data('sort-id');
            
            // 移除所有卡片的active类
            $('.sort-card').removeClass('active');
            
            // 为当前点击的卡片添加active类
            $this.addClass('active');
            
            // 更新隐藏的sort_id输入框的值
            $('#sort_id').val(sortId);
            
            // 根据分类筛选商品
            filterGoodsBySort(sortId);
            
            // 分类变化后的逻辑
            console.log('选择的分类ID:', sortId);
        });

        // 商品卡片点击事件
        $('.goods-cards-container').on('click', '.goods-card', function(){
            var $card = $(this);
            var $checkbox = $card.find('input[type="checkbox"]');
            
            // 切换checkbox状态
            $checkbox.prop('checked', !$checkbox.prop('checked'));
            
            // 更新卡片选中状态
            if ($checkbox.prop('checked')) {
                $card.addClass('selected');
            } else {
                $card.removeClass('selected');
            }
            
            // 更新选中的商品ID列表
            updateGoodsIds();
        });

        // 根据分类筛选商品
        function filterGoodsBySort(sortId) {
            $('.goods-card').each(function(){
                var $card = $(this);
                var goodsSortId = $card.data('sort-id');
                
                if (sortId == '' || goodsSortId == sortId) {
                    $card.removeClass('hidden');
                } else {
                    $card.addClass('hidden');
                }
            });
        }

        // 更新选中的商品ID列表
        function updateGoodsIds() {
            var selectedIds = [];
            $('.goods-card input[type="checkbox"]:checked').each(function(){
                selectedIds.push($(this).val());
            });
            $('#goods_ids').val(selectedIds.join(','));
        }

        // 页面加载时初始化
        $(document).ready(function(){
            // 如果有默认选中的分类，执行筛选
            var defaultSortId = $('#sort_id').val();
            if (defaultSortId) {
                filterGoodsBySort(defaultSortId);
            }
        });

        form.on('submit(submit)', function(data){
            var field = data.field; // 获取表单全部字段值
            var url = $('#form').attr('action');
            $.ajax({
                type: "POST",
                url: url,
                data: field,
                dataType: "json",
                success: function (e) {
                    if(e.code != 200){
                        layer.msg(e.msg);
                        return false;
                    }
                    parent.layer.msg('添加成功');
                    parent.layer.close('add_goods');
                },
                error: function (xhr) {
                    layer.msg(JSON.parse(xhr.responseText).msg);
                },
                complete: function() {
                }
            });


            return false; // 阻止默认 form 跳转
        });
    })



    /*var maxHeight = $(window.parent).innerHeight() * 0.75;
    // 2. 为 #open-box 设置 max-height，同时添加溢出滚动
    $("#open-box").css({
        "max-height": maxHeight + "px", // 单位必须加 px
        "overflow-y": "auto" // 内容超过 max-height 时显示垂直滚动条
    });*/
</script>
<?php endif; ?>
<?php endif; ?>

