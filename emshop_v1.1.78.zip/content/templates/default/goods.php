<?php
/**
 *
 */
defined('EM_ROOT') || exit('access denied!');

$payment = getPayment();

// d($payment);die;
?>

<style>
    .stat-item {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        background: #f8f9fa;
        border-radius: 20px;
        margin-right: 10px;
        font-size: 13px;
        border: 1px solid #e9ecef;
        transition: all 0.3s ease;
    }
    
    .stat-item:hover {
        background: #EDF2F1;
        border-color: #4C7D71;
        transform: translateY(-1px);
        box-shadow: 0 2px 8px rgba(76, 125, 113, 0.15);
    }
    
    .stat-icon {
        font-size: 14px;
    }
    
    .stat-label {
        color: #6c757d;
        font-weight: 500;
    }
    
    .stat-value {
        color: #495057;
        font-weight: 600;
    }
    
    .stock-stat .stat-value {
        color: #0d6efd;
    }
    
    .sales-stat .stat-value {
        color: #20c997;
    }
</style>

<article class="container goods-con">

    <div class="card">
        <div class="row no-gutters">
            <div class="col-md-4" style="padding: 10px;">
                <img class="goods-cover" src="<?= $goods['cover'] ?>" alt="" style="" onerror="this.src='<?= EM_URL ?>admin/views/images/cover.svg'; this.onerror=null;" />
            </div>
            <div class="col-md-8" style="padding-bottom: 1rem;">
                <div class="card-body goods-attr" style="padding-bottom: 0;">
                    <h3 class="card-title"><?= $goods['title'] ?></h3>
                    <p class="card-text">
                        <?php if(_g('stock_show') != 'n'): ?>
                            <span class="stat-item stock-stat">
                                <i class="stat-icon">📦</i>
                                <span class="stat-label">库存</span>
                                <span id="stock" class="dynamic-stock stat-value"><?= $goods['stock'] ?></span>
                            </span>
                        <?php endif; ?>
                        <?php if(_g('sales_show') != 'n'): ?>
                            <span class="stat-item sales-stat">
                                <i class="stat-icon">📈</i>
                                <span class="stat-label">销量</span>
                                <span id="sales" class="dynamic-sales stat-value"><?= $goods['sales'] ?></span>
                            </span>
                        <?php endif; ?>
                    </p>
                    <div style="margin-bottom: 15px;">
                        <span class="currency">¥</span>
                        <span class="price dynamic-price" id="price"><?= $goods['price'] ?></span>
                    </div>

                    <div class="col-lg-12" style="padding: 0;">
                        <!-- 开发模板，可直接复用此处 -->
                        <form class="drawer-content layui-form" id="buyForm">
                            <!-- 规格选择 -->
                            <input type="hidden" name="goods_id" id="goods_id" value="<?= $goods['id'] ?>">
                            <?php foreach($goods['spec'] as $val): ?>
                                <div class="form-group spec-group">
                                    <div class="form-title">
                                        <?= $val['title'] ?>
                                    </div>
                                    <div class="spec-options">
                                        <?php foreach($val['sku_values'] as $v): ?>
                                            <div class="spec-option" data-id="<?= $v['id'] ?>"><?= $v['name'] ?></div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <!-- 购买数量 -->
                            <div class="form-group">
                                <div class="form-title">
                                    <i class="fa fa-calculator"></i>购买数量
                                </div>
                                <div class="quantity-selector">
                                    <div class="quantity-btn minus" id="drawerMinusBtn"><i class="fa fa-minus"></i></div>
                                    <input type="number" class="quantity-input" name="quantity" id="quantity" value="1" min="1">
                                    <div class="quantity-btn plus" id="drawerPlusBtn"><i class="fa fa-plus"></i></div>
                                </div>
                            </div>
                            <!-- 自定义输入信息 -->
                            <?php foreach($goods['input'] as $key => $val): ?>
                            <?php foreach($val as $k => $v): ?>
                            <div class="form-group">
                                <div class="form-title"><?= $v['name'] ?></div>
                                <div class="layui-form-item">
                                    <div class="layui-input-block">
                                        <input type="text" name="<?= $key ?>[<?= $v['name'] ?>]" placeholder="<?= $v['placeholder'] ?>" autocomplete="off" class="layui-input <?= $key ?>-input">
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <?php endforeach; ?>
                            <!-- 支付方式选择 -->
                            <div class="form-group">
                                <div class="form-title">
                                    <i class="fa fa-credit-card"></i>选择支付方式
                                </div>
                                <div class="payment-methods">
                                    <?php foreach($payment as $val): ?>
                                        <div class="payment-item" data-method="<?= $val['plugin_name'] ?>">
                                            <div class="payment-icon">
                                                <img src="<?= $val['icon'] ?>" alt="<?= $val['title'] ?>">
                                            </div>
                                            <div class="payment-info">
                                                <div class="payment-name"><?= $val['title'] ?></div>
                                            </div>
                                            <div class="payment-checked layui-icon layui-icon-ok-circle"></div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <!-- 提交订单 -->
                            <div class="drawer-footer">
                                <div class="drawer-actions">
                                    <button class="drawer-btn buy-btn-g" lay-submit lay-filter="buy-submit">
                                        立即购买
                                        <span class="total-price">¥<span class="dynamic-price"><?= $goods['price'] ?></span></span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="card" style="padding: 15px;">
        <div class="markdown intro" id="emlogEchoLog"><?= $goods['content'] ?></div>
    </div>





    <div style="clear:both;"></div>
</article>


<script>
    layui.use(['carousel', 'layer'], function() {
        var $ = layui.$;
        var form = layui.form;
        var layer = layui.layer;
        // 内容图片错误处理
        $('.intro img').each(function() {
            var img = this;
            img.onerror = function() {
                img.src = '<?= EM_URL ?>admin/views/images/cover.svg';
                img.onerror = null;
            };
            // 如果图片已经加载失败（针对缓存或快速加载的情况）
            if (img.complete && img.naturalWidth === 0) {
                img.src = '<?= EM_URL ?>admin/views/images/cover.svg';
            }
        });
        form.on('submit(buy-submit)', function(data){
            toBuy();
            return false; // 阻止默认 form 跳转
        });
        // 页面加载时初始化规格库存状态
        refreshGoodsInfo();
    })
</script>

<?php include View::getCommonView('footer') ?>