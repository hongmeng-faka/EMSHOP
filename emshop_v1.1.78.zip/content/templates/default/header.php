<?php
/*
Template Name:默认模板
Version:1.3.0
Template Url:
Description:系统默认的自适应模板
Author:驳手
Author Url:
*/


?>
