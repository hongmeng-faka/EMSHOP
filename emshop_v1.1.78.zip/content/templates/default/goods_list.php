<?php
/**
 * 首页模板
 */
defined('EM_ROOT') || exit('access denied!');
?>
<?php doAction('goods_list'); ?>

<style>
    /* 页面容器 */
    .blog-container {
        max-width: 1200px;
        margin: 20px auto;
        padding: 0 15px;
        width: 100%;
    }

    /* 公告栏 */
    .notice-bar {
        background: #fff;
        border-radius: 8px;
        padding: 15px 20px;
        display: flex;
        align-items: center;
        box-shadow: 0 1px 6px rgba(0,0,0,0.05);
        margin-bottom: 20px;
        border-left: 4px solid #4C7D71;
    }
    .notice-bar .layui-icon {
        color: #4C7D71;
        font-size: 20px;
        margin-right: 12px;
    }
    .notice-content {
        color: #666;
        font-size: 14px;
        flex: 1;
    }

    /* 分类导航 */
    .category-section {
        background: #fff;
        border-radius: 16px;
        padding: 15px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.04);
        margin-bottom: 25px;
    }
    .category-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(90px, 1fr));
        gap: 20px 15px;
        justify-items: center;
    }
    .category-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        width: 100%;
        transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        cursor: pointer;
    }
    .category-item:hover {
        transform: translateY(-5px);
    }
    .category-icon {
        width: 64px;
        height: 64px;
        border-radius: 22px;
        background: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 12px;
        transition: all 0.3s;
        overflow: hidden;
    }
    .category-item:hover .category-icon {
        background: #EDF2F1;
        box-shadow: 0 6px 15px rgba(76, 125, 113, 0.2);
    }
    .category-icon img {
        width: 42px;
        height: 42px;
        object-fit: cover;
        border-radius: 10px;
        transition: transform 0.3s;
    }
    .category-item:hover .category-icon img {
        transform: scale(1.1);
    }
    .category-item span {
        font-size: 14px;
        color: #444;
        font-weight: 500;
        transition: color 0.3s;
        /* 单行截断 */
        width: 100%;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: clip; /* 不显示省略号 */
        padding: 0 4px;
    }
    .category-item:hover span {
        color: #4C7D71;
        font-weight: 600;
    }

    /* 商品列表 */
    .goods-card {
        display: block;
        background: #fff;
        border-radius: 10px;
        overflow: hidden;
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        position: relative;
        border: 1px solid #f0f0f0;
    }
    .goods-card:hover {
        box-shadow: 0 10px 20px rgba(0,0,0,0.08);
        border-color: transparent;
        z-index: 2;
    }
    .goods-img-box {
        position: relative;
        width: 100%;
        padding-top: 100%; /* 1:1 Aspect Ratio */
        background: #f9f9f9;
        overflow: hidden;
    }
    .goods-img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s ease;
    }
    .goods-card:hover .goods-img {
        transform: scale(1.08);
    }
    .goods-info {
        padding: 12px;
    }
    .goods-title {
        font-size: 14px;
        color: #333;
        line-height: 1.5;
        height: 42px;
        font-weight: 500;
    }
    .goods-price-row {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
    }
    .price-current {
        color: #ff4d4f;
        font-weight: bold;
        font-size: 18px;
        line-height: 1;
    }
    .price-current small {
        font-size: 12px;
        margin-right: 1px;
    }
    .price-market {
        color: #ccc;
        font-size: 12px;
        text-decoration: line-through;
        margin-left: 5px;
    }
    .buy-icon {
        width: 24px;
        height: 24px;
        background: #f5f5f5;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #999;
        transition: all 0.2s;
    }
    .goods-card:hover .buy-icon {
        background: #4C7D71;
        color: #fff;
    }
    .goods-stats {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: #999;
        margin-bottom: 8px;
        margin-top: 5px;
    }
    .goods-stats span {
        display: flex;
        align-items: center;
        gap: 3px;
    }
    .goods-stats .fa {
        font-size: 12px;
    }
    
    /* 美化的统计信息样式 */
    .stat-item {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 3px 8px;
        background: #f8f9fa;
        border-radius: 16px;
        font-size: 11px;
        border: 1px solid #e9ecef;
        transition: all 0.3s ease;
    }
    
    .stat-item:hover {
        background: #EDF2F1;
        border-color: #4C7D71;
        transform: translateY(-1px);
        box-shadow: 0 2px 6px rgba(76, 125, 113, 0.1);
    }
    
    .stat-icon {
        font-size: 12px;
    }
    
    .stat-label {
        color: #6c757d;
        font-weight: 500;
    }
    
    .stat-value {
        color: #495057;
        font-weight: 600;
    }
    
    .stock-stat .stat-value {
        color: #0d6efd;
    }
    
    .sales-stat .stat-value {
        color: #20c997;
    }

    /* 空状态 */
    .empty-container {
        padding: 60px 0;
        text-align: center;
    }
    .empty-icon {
        font-size: 60px;
        color: #e0e0e0;
        margin-bottom: 20px;
    }
    .empty-text {
        color: #999;
        font-size: 16px;
        margin-bottom: 25px;
    }
</style>

<main class="blog-container">

    <?php doAction('index_sorts_top'); ?>

    <!-- 公告栏 -->
    <?php if (!empty(Option::get('home_bulletin'))): ?>
        <div class="notice-bar">
            <i class="layui-icon layui-icon-speaker"></i>
            <div class="notice-content">
                <?= Option::get('home_bulletin') ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- 分类导航 -->
    <?php if (!empty($sort) && _g('category_show') == 'y'): ?>
        <div class="category-section">
            <div class="category-grid">
                <?php foreach ($sort as $val): ?>
                    <a href="<?= Url::sort($val['sid']) ?>" class="category-item">
                        <div class="category-icon">
                            <img src="<?= $val['sortimg'] ?>" alt="<?= $val['sortname'] ?>" onerror="this.src='<?= EM_URL ?>admin/views/images/cover.svg'; this.onerror=null;">
                        </div>
                        <span><?= $val['sortname'] ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- 商品列表 -->
    <div class="goods-list-section">
        <?php doAction('index_goodslist_top'); ?>
        
        <?php if (!empty($goods_list)): ?>
            <div class="grid-cols-lg-6 grid-cols-md-4 grid-cols-sm-3 grid-cols-xs-2 grid-gap-15">
                <?php foreach ($goods_list as $key => $val): ?>
                    <a class="goods-card" href="<?= $val['url'] ?>" title="<?= $val['title'] ?>">
                        <div class="goods-img-box">
                            <img class="goods-img lazy" src="<?= $val['cover'] ?>" alt="<?= $val['title'] ?>" loading="lazy" onerror="this.src='<?= EM_URL ?>admin/views/images/cover.svg'; this.onerror=null;">
                        </div>
                        
                        <div class="goods-info">
                            <div class="goods-title row-2-hidden">
                                <?= $val['title'] ?>
                            </div>
                            <div class="goods-stats">
                                <?php if(_g('stock_show') != 'n'): ?>
                                <span class="stat-item stock-stat"><span class="stat-label">库存:</span> <span class="stat-value"><?= $val['stock'] ?? 0 ?></span></span>
                                <?php endif; ?>
                                <?php if(_g('sales_show') != 'n'): ?>
                                <span class="stat-item sales-stat"><span class="stat-label">销量:</span> <span class="stat-value"><?= $val['sales'] ?? 0 ?></span></span>
                                <?php endif; ?>
                            </div>

                            <div class="goods-price-row">
                                <div class="price-wrap">
                                    <span class="price-current"><small>&yen;</small><?= $val['price'] ?></span>
                                    <?php if (!empty($val['market_price'])): ?>
                                        <span class="price-market">&yen;<?= $val['market_price'] ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="buy-icon">
                                    <i class="layui-icon layui-icon-cart"></i>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <!-- 空状态 -->
            <div class="empty-container">
                <i class="layui-icon layui-icon-face-surprised empty-icon"></i>
                <div class="empty-text">抱歉，暂时没有找到相关商品</div>
                <a href="/" class="layui-btn layui-btn-primary layui-btn-radius">返回首页</a>
            </div>
        <?php endif ?>
    </div>

</main>
