<?php
defined('EM_ROOT') || exit('access denied!');

// 启用主题时执行该函数
function callback_init() {
    // do something
}

// 删除主题时执行该函数
function callback_rm() {
    // do something
}

// 更新主题时执行该函数
function callback_up() {
    // do something
}
