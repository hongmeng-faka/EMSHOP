<?php

/**
 * 请勿随意更改此文件，文件改动会造成程序无法正常使用
 */

// 在线更新服务
const SERVICE_TOKEN = 'Qian7sT3vB9';


