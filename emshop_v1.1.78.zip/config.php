<?php
header("location: ./install.php"); die;